<!DOCTYPE html>
<html lang="en" class="overflow-x-hidden">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>REDES Creation - Web Development Company & Digital Agency</title>

    <!-- SEO Meta Tags -->
<title>Redes Creation | Web Development, Marketing & Design Agency</title>
<meta name="description" content="Redes Creation is a creative digital agency offering web development, digital marketing, branding, and graphic design services.">
<meta name="keywords" content="Redes Creation, web development, digital marketing, branding, graphic design, India">
<meta name="author" content="Redes Creation">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Open Graph Meta Tags for Social Sharing -->
<meta property="og:title" content="Redes Creation | Web Development, Marketing & Design Agency">
<meta property="og:description" content="Creative digital agency offering full-service solutions for your online business needs.">
<meta property="og:image" content="https://redescreation.in/images/cover.jpg">
<meta property="og:url" content="https://redescreation.in/">
<meta property="og:type" content="website">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Redes Creation | Web Development, Marketing & Design Agency">
<meta name="twitter:description" content="Creative digital agency offering full-service solutions for your online business needs.">
<meta name="twitter:image" content="https://redescreation.in/images/cover.jpg">
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: { primary: "#034bc0", secondary: "#4B4B4B" },
            borderRadius: {
              none: "0px",
              sm: "4px",
              DEFAULT: "8px",
              md: "12px",
              lg: "16px",
              xl: "20px",
              "2xl": "24px",
              "3xl": "32px",
              full: "9999px",
              button: "8px",
            },
          },
        },
      };
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.min.css"
    />
    <style>
      :where([class^="ri-"])::before { content: "\f3c2"; }
      body {
          font-family: 'Montserrat', sans-serif;
          scroll-behavior: smooth;
      }
      .nav-blur {
          backdrop-filter: blur(10px);
          background-color: rgba(255, 255, 255, 0.8);
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
          transition: all 0.3s ease;
      }
      .service-card {
          transition: all 0.3s ease;
          overflow: hidden;
          position: relative;
      }
      .service-card:hover {
          transform: translateY(-5px);
      }
      .service-card:hover .service-icon {
          transform: scale(1.1);
      }
      .service-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(135deg, rgba(192, 3, 3, 0.9), rgba(192, 3, 3, 0.7));
          opacity: 0;
          transition: all 0.3s ease;
          z-index: 1;
      }
      .service-card:hover::before {
          opacity: 1;
      }
      .service-card:hover .service-content {
          color: white;
          z-index: 2;
          position: relative;
      }
      .service-card:hover .service-title {
          color: white;
      }
      .service-icon {
          transition: all 0.3s ease;
      }
      .btn-primary {
          background: linear-gradient(135deg, #034bc0, #0140b3);
          transition: all 0.3s ease;
          box-shadow: 0 4px 15px rgb(43 138 255 / 30%);
      }
      .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(192, 3, 3, 0.4);
      }
      .btn-outline {
          transition: all 0.3s ease;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      }
      .btn-outline:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
      }
      .fade-in {
          animation: fadeIn 0.8s ease-in-out;
      }
      @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
      }
      .hero-bg {
          background: linear-gradient(135deg, rgb(3 75 192 / 90%), rgb(6 55 163 / 80%)),
                      url('assets/img/hero-bg.png');
          background-size: cover;
          background-position: center;
      }
      .footer-bg {
          background: linear-gradient(135deg, #1a1a1a, #333333);
      }
      .social-icon {
          transition: all 0.3s ease;
      }
      .social-icon:hover {
          transform: translateY(-3px);
          filter: drop-shadow(0 0 8px rgba(255, 255, 255, 0.6));
      }
      .nav-link {
          position: relative;
      }
      .nav-link::after {
          content: '';
          position: absolute;
          bottom: -4px;
          left: 0;
          width: 0;
          height: 2px;
          background-color: #034bc0;
          transition: width 0.3s ease;
      }
      .nav-link:hover::after {
          width: 100%;
      }
      .portfolio-item {
          overflow: hidden;
      }
      .portfolio-item img {
          transition: transform 0.5s ease;
      }
      .portfolio-item:hover img {
          transform: scale(1.05);
      }
      .portfolio-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(to top, rgb(3 68 192 / 90%), rgb(3 61 192 / 30%));
          opacity: 0;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          justify-content: center;
      }
      .portfolio-item:hover .portfolio-overlay {
          opacity: 1;
      }
	  #navbar{
			background-color: white;
	  }
	  #flex-screen{
			min-height: 95vh;
      }
	  #tech{
			height: auto;
			max-width: 100%;
			vertical-align: middle;
	  }
	  .w-24 {
    width: 10rem;
}
#mascot {

    width: 9rem;
    --tw-translate-y: -80%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}


    </style>
    
<link rel="icon" type="image/png" href="/assets/favicon-rc-new.png" sizes="192x192">
<link rel="apple-touch-icon" href="/assets/favicon-rc-new.png">
<link rel="shortcut icon" href="/assets/favicon-rc-new.png">
<meta name="msapplication-TileImage" content="/assets/favicon-rc-new.png">
    
  </head>
  <body class="overflow-x-hidden">
    <!-- Header & Navigation -->
    <!-- HEADER START -->
<header class="header-bar">
  <nav class="nav-container">
    <!-- Logo -->
    <a href="/" class="nav-logo">
      <img src="images/redescreation-logo.png" alt="Redes Creation" class="logo-img">
      <span class="logo-text"></span>
    </a>
    <!-- Desktop Menu -->
    <ul class="nav-menu">
      <li class="nav-item dropdown">
        <a href="/" class="nav-link">Home</span></a>
        <!-- Example dropdown
        <ul class="dropdown-menu">
          <li><a href="#">Submenu 1</a></li>
          <li><a href="#">Submenu 2</a></li>
        </ul>
        -->
      </li>
      <li class="nav-item dropdown">
        <a href="about.php" class="nav-link">About</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="portfolio.php" class="nav-link">Portfolio</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="services.php" class="nav-link">Service</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="blogs" class="nav-link">Blogs</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="contact.php" class="nav-link">Contact</span></a>
      </li>
    </ul>
    <!-- Right CTA Button -->
    <a href="quote.php" class="nav-cta">Request a Quote <span class="cta-icon">&#8594;</span></a>
    <!-- Hamburger Icon -->
    <div class="nav-hamburger" id="hamburger-btn">
      <span></span><span></span><span></span>
    </div>
  </nav>
  <!-- Mobile Menu -->
  <div class="mobile-menu" id="mobile-menu">
    <ul>
      <li><a href="/">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="portfolio.php">Portfolio</a></li>
      <li><a href="services.php">Service</a></li>
      <li><a href="blogs">Blogs</a></li>
      <li><a href="contact.php">Contact Us <span class="cta-icon">&#8594;</span></a></li>
    </ul>
  </div>
</header>

<style>
/* Header Section */
.header-bar {
  position: fixed;
  top: 24px;
  left: 0; right: 0;
  z-index: 9999;
  width: 100%;
  display: flex;
  justify-content: center;
  pointer-events: none;
}
.nav-container {
  width: 90vw;
  max-width: 1300px;
  background: #fff;
  border-radius: 48px;
  box-shadow: 0 6px 32px 0 rgba(32, 50, 90, 0.10);
  display: flex;
  align-items: center;
  padding: 0 32px 0 18px;
  min-height: 74px;
  pointer-events: auto;
  gap: 20px;
}
.nav-logo {
  display: flex;
  align-items: center;
  gap: 0.6em;
  margin-right: 22px;
}
.logo-img {
  max-height: 44px;
  min-width: 44px;
}
.logo-text {
  font-size: 2rem;
  font-weight: 700;
  letter-spacing: -2px;
  margin-top: 1px;
}
.nav-menu {
  display: flex;
  align-items: center;
  gap: 8px;
  list-style: none;
  margin: 0 0 0 16px;
  padding: 0;
  flex: 1 1 auto;
}
.nav-item {
  position: relative;
}
.nav-link {
  display: flex;
  align-items: center;
  font-size: 17px;
  font-weight: 500;
  color: #202834;
  padding: 16px 18px 16px 12px;
  border-radius: 32px;
  text-decoration: none;
  transition: background 0.18s;
}
.nav-link:hover {
  background: #ecf0fa;
  color: #2074ff;
}
.dropdown-icon {
  font-size: 13px;
  margin-left: 5px;
  margin-top: 1px;
}
.search-btn .search-toggle {
  background: none;
  border: none;
  font-size: 20px;
  padding: 10px 10px;
  border-radius: 999px;
  cursor: pointer;
  color: #222;
  transition: background 0.2s;
}
.search-btn .search-toggle:hover {
  background: #ecf0fa;
}
.nav-cta {
  background: #256eff;
  color: #fff;
  font-size: 18px;
  padding: 10px 24px;
  border-radius: 999px;
  font-weight: 600;
  margin-left: 24px;
  display: flex;
  align-items: center;
  text-decoration: none;
  transition: background 0.18s, box-shadow 0.18s;
  box-shadow: 0 2px 20px 0 rgba(32, 58, 255, 0.11);
}
.nav-cta:hover {
  background: #0450d9;
}
.cta-icon {
  font-size: 1.5em;
  margin-left: 10px;
}
.nav-hamburger {
  display: none;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  height: 46px; width: 46px;
  border-radius: 100%;
  margin-left: 18px;
  transition: background 0.2s;
}
.nav-hamburger:hover { background: #f4f7fb;}
.nav-hamburger span {
  display: block;
  background: #222;
  height: 4px; width: 28px;
  border-radius: 2px;
  margin: 3px 0;
  transition: all 0.23s;
}
/* Mobile menu */
.mobile-menu {
  display: none;
  flex-direction: column;
  align-items: center;
  position: fixed;
  top: 100px; left: 0; right: 0;
  background: #fff;
  box-shadow: 0 8px 32px 0 rgba(31,38,135,0.09);
  z-index: 9999;
  border-radius: 0 0 32px 32px;
  padding: 22px 0 26px 0;
  pointer-events: auto;
}
.mobile-menu ul {
  width: 95vw;
  max-width: 360px;
  margin: 0 auto;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.mobile-menu li a, .mobile-menu li {
  display: block;
  padding: 14px 10px;
  color: #2d3652;
  font-size: 18px;
  text-align: left;
  border-radius: 22px;
  text-decoration: none;
  font-weight: 500;
  margin: 0;
  transition: background 0.16s, color 0.12s;
}
.mobile-menu li a:hover {
  background: #ecf0fa;
  color: #0450d9;
}
.mobile-menu .cta-icon {
  margin-left: 8px;
}
@media (max-width: 1100px) {
  .nav-container { width: 98vw; min-width: unset;}
}
@media (max-width: 900px) {
  .nav-container { padding: 0 12px; }
  .logo-text { font-size: 1.35rem; }
  .nav-link { font-size: 16px; padding: 16px 10px;}
  .nav-cta { font-size: 15px; padding: 11px 18px; margin-left: 12px;}
}
@media (max-width: 800px) {
  .nav-menu { gap: 3px; }
  .nav-container { gap:10px;}
}
@media (max-width: 700px) {
  .nav-container { min-height: 58px; border-radius: 36px;}
  .nav-logo .logo-img { max-height: 38px;}
}
@media (max-width: 650px) {
  .nav-menu, .nav-cta { display: none; }
  .nav-hamburger { display: flex; }
  .mobile-menu { border-radius: 0 0 16px 16px; }
  .header-bar {top:10px;}
}
</style>
<script>
const hamburger = document.getElementById("hamburger-btn");
const mobileMenu = document.getElementById("mobile-menu");
let menuOpen = false;
hamburger.addEventListener("click", () => {
  menuOpen = !menuOpen;
  mobileMenu.style.display = menuOpen ? "flex" : "none";
});
window.addEventListener('resize', function() {
  if(window.innerWidth > 650){
    mobileMenu.style.display = 'none';
    menuOpen = false;
  }
});
// Optional: Close menu on link click
mobileMenu.querySelectorAll('a').forEach(link =>
  link.addEventListener('click', () => { 
    mobileMenu.style.display = 'none'; 
    menuOpen = false; 
  })
);
</script>

<section id="hero" class="relative w-full min-h-[100vh] flex items-center justify-center overflow-hidden bg-[#0042AA] text-white">

  <!-- Animated SVG Background -->
  <svg class="absolute inset-0 w-full h-full z-0 pointer-events-none" aria-hidden="true">
    <defs>
      <linearGradient id="heroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop stop-color="#00AAE4" stop-opacity="0.25"/>
        <stop stop-color="#0042AA" stop-opacity="1"/>
      </linearGradient>
    </defs>
    <rect width="100%" height="100%" fill="url(#heroGradient)"/>
    <g>
      <animateTransform attributeName="transform" type="translate" values="0 0;50 0;0 0" dur="4s" repeatCount="indefinite" />
      <path d="M 80 0 L 100 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
      <path d="M 300 0 L 500 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
      <path d="M 700 0 L 900 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
    </g>
  </svg>

  <!-- Main Content with max-w-7xl -->
  <div class="max-w-7xl mx-auto w-full flex flex-col md:flex-row items-center justify-between z-10 relative">
    <!-- Left Side: Text Content -->
    <div class="flex-1 flex flex-col justify-center pl-8 md:pl-24 pt-24" style="max-width:640px;">
      <span 
        class="block text-[#00AAE4] font-bold mb-2 tracking-wide animate-fade-in"
        style="animation-delay:0.2s"
      >Top #1 IT Solution Agency</span>
      <h1 
        class="text-4xl md:text-5xl font-extrabold mb-8 animate-slide-up"
        style="animation-delay:0.4s"
      >
        Next-Generation IT<br>
        Solutions for Every<br>
        Business
      </h1>
      <p 
        class="mb-10 text-lg text-white/95 animate-slide-up"
        style="animation-delay:0.5s"
      >
        We specialize delivering innovative, tailored IT solutions that empower businesses to thrive in today’s digital landscape.
      </p>
      <div class="flex gap-4">
        <a href="#stories" 
           class="bg-blue hover:bg-white text-white hover:text-[#0042AA] font-semibold px-7 py-3 rounded-lg shadow-md border border-white transition duration-300 animate-scale-up"
           style="animation-delay:0.7s"
        >
          Our Success Stories &rarr;
        </a>
        <a href="contact.php" 
           class="bg-blue text-white hover:bg-[#00AAE4] hover:text-white font-semibold px-7 py-3 rounded-lg shadow-md border border-[#00AAE4] transition duration-300 animate-scale-up"
           style="animation-delay:0.75s"
        >
          Contact Us &rarr;
        </a>
      </div>
      <!-- Experience Badge, animated entry -->
      <div class="mt-8 animate-bounce-in" style="animation-delay:1s">
        <span class="bg-white text-[#0042AA] px-5 py-3 rounded-full font-semibold flex items-center gap-2 shadow">
          <svg class="w-5 h-5 text-[#00AAE4]" fill="currentColor" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" /></svg>
          With 5+ years of experience helping the community.
        </span>
      </div>
    </div>
    <!-- Right Side: Image -->
    <div class="flex-1 flex justify-end items-end pr-4 md:pr-24 pt-32">
      <img 
        src="assets/hero20-img1.png" 
        alt="IT Team" 
        class="h-[400px] md:h-[624px] w-auto object-contain animate-pop-in"
        style="animation-delay:1.3s"
      />
    </div>
  </div>

  <style>
    @keyframes fade-in { from {opacity:0} to {opacity:1} }
    @keyframes slide-up { from {opacity:0;transform:translateY(40px);} to {opacity:1;transform:translateY(0);} }
    @keyframes scale-up { from {opacity:0;transform:scale(0.85);} to {opacity:1;transform:scale(1);} }
    @keyframes bounce-in { 0% {opacity:0;transform:translateY(40px);} 50% {opacity:0.8;} 100% {opacity:1;transform:translateY(0);} }
    @keyframes pop-in { from {opacity:0;transform:scale(0.93) rotate(-10deg);} to {opacity:1;transform:scale(1) rotate(0deg);} }
    .animate-fade-in{
      animation: fade-in 1.2s forwards;
    }
    .animate-slide-up{
      animation: slide-up 1.15s cubic-bezier(.42,0,.58,1.2) forwards;
    }
    .animate-scale-up{
      animation: scale-up 1s cubic-bezier(.57,1.42,.33,.99) forwards;
    }
    .animate-bounce-in{
      animation: bounce-in 1.1s cubic-bezier(.57,1.42,.33,.99) forwards;
    }
    .animate-pop-in{
      animation: pop-in 1.6s cubic-bezier(.57,1.42,.33,.99) forwards;
    }
    /* Mobile responsive (optional extra) */
    @media (max-width: 640px){
      #hero {
        flex-direction: column;
        padding-top: 2rem;
      }
      #hero .flex-1 {
        max-width: 100vw !important;
      }
      #hero img {
        height: 220px !important;
        margin-top: 2rem;
      }
    }
    
  </style>

  <!-- JS for scroll-triggered/repeated animations (optional) -->
  <script>
    // Animate on scroll into view (for parallax or extra)
    function animateOnVisible(){
      document.querySelectorAll('[class*="animate-"]').forEach(el=>{
        const rect = el.getBoundingClientRect();
        if (rect.top<window.innerHeight-20){
          el.style.animationPlayState='running';
        }
      });
    }
    window.addEventListener('scroll', animateOnVisible);
    window.addEventListener('DOMContentLoaded', animateOnVisible);
  </script>
</section>

<section class="w-full bg-[#FBFBFB] text-[#18191F] py-16">
  <div class="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-10 px-6"  >
    <!-- Images Column -->
    <div class="flex flex-row gap-6 items-center">
      <img src="assets/about4-image1.webp" alt="Digital Marketing" class="rounded-2xl w-64 h-80 object-cover shadow-lg animate-fade-in" style="animation-delay:0.1s">
      <img src="assets/about4-image3.webp" alt="Fintech Card" class="rounded-2xl w-56 h-72 object-cover shadow-lg animate-fade-in" style="animation-delay:0.2s">
    </div>
    <!-- Content Column -->
    <div class="flex-1 animate-slide-up" style="animation-delay:0.25s">
      <div class="flex items-center gap-2 mb-2">
        <svg class="w-5 h-5 text-[#00AAE4]" fill="currentColor" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" /></svg>
        <span class="uppercase font-semibold tracking-wide text-lg">About Us</span>
      </div>
      <h2 class="text-3xl md:text-4xl font-bold mb-4 text-[#18191F]">
        Your Trusted Partner in<br>
        Digital Growth
      </h2>
      <p class="mb-7 text-[#222] text-lg leading-relaxed">
        With years of experience and a team of creative minds, our digital marketing agency specializes in helping businesses thrive in the digital age. We combine innovation, data-driven insights, and a personalized approach to craft strategies that resonate with your audience and achieve your goals.
      </p>
      <h3 class="font-semibold text-[#18191F] text-lg mb-3">Our Best Service Benefits :</h3>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-y-2 gap-x-8 mb-7 text-lg">
        <div class="flex items-center gap-2">
          <span class="w-6 h-6 flex items-center justify-center bg-[#256eff] text-white rounded-full font-bold shadow">
            &#x2714;
          </span>Digital Marketing
        </div>
        <div class="flex items-center gap-2">
          <span class="w-6 h-6 flex items-center justify-center bg-[#256eff] text-white rounded-full font-bold shadow">
            &#x2714;
          </span>SEO Optimization
        </div>
        <div class="flex items-center gap-2">
          <span class="w-6 h-6 flex items-center justify-center bg-[#256eff] text-white rounded-full font-bold shadow">
            &#x2714;
          </span>Marketing Agency
        </div>
        <div class="flex items-center gap-2">
          <span class="w-6 h-6 flex items-center justify-center bg-[#256eff] text-white rounded-full font-bold shadow">
            &#x2714;
          </span>First Working Process
        </div>
      </div>
      <a href="#contact" class="inline-block px-9 py-4 bg-[#256eff] text-white font-bold rounded-full shadow-lg text-lg transition duration-300 hover:bg-[#00AAE4] hover:text-white animate-scale-up"
         style="animation-delay:0.35s">
        Learn More
      </a>
    </div>
  </div>
  <style>
    @keyframes fade-in { from {opacity:0;transform:translateY(30px);} to {opacity:1;transform:translateY(0);} }
    @keyframes slide-up { from {opacity:0;transform:translateY(40px);} to {opacity:1;transform:translateY(0);} }
    @keyframes scale-up { from {opacity:0;transform:scale(0.93);} to {opacity:1;transform:scale(1);} }
    .animate-fade-in{animation:fade-in 1s cubic-bezier(.57,1.42,.33,.99) forwards;}
    .animate-slide-up{animation:slide-up 0.85s cubic-bezier(.42,0,.58,1.2) forwards;}
    .animate-scale-up{animation:scale-up 1s cubic-bezier(.57,1.42,.33,.99) forwards;}
  </style>
</section>

<!-- HERO SERVICES SLIDER SECTION (Tailwind + Advanced JS) -->
<section id="hero-services" class="relative w-full min-h-screen bg-[#0042AA] text-white overflow-hidden">
  <!-- Full-section background (images are rendered by JS so they cover entire section) -->
  <div id="hero-bg" class="absolute inset-0 z-0 overflow-hidden">
    <!-- JS injects <img> here with object-cover to fill the full section -->
  </div>

  <!-- Content canvas: everything visible aligned to max-w-7xl -->
  <div class="relative z-20 max-w-7xl mx-auto px-6 py-20">
    <!-- Central slider area -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
      <!-- Left content (col-span 7 on large screens) -->
      <div class="lg:col-span-7 col-span-1">
        <div class="flex items-center mb-6">
          <span class="w-24 h-[2px] bg-blue-400 mr-6"></span>
          <span class="uppercase font-medium tracking-widest text-sm text-white/90">Our Services</span>
        </div>
        <h1 id="slide-title" class="text-3xl sm:text-4xl md:text-5xl font-extrabold mb-6 leading-tight drop-shadow-lg"></h1>
        <p id="slide-desc" class="mb-8 text-base sm:text-lg text-white/95 max-w-2xl"></p>

        <div class="flex flex-col sm:flex-row gap-4">
          <a href="services.php" class="inline-block bg-blue text-white border border-white font-semibold px-8 py-3 rounded-lg shadow-md whitespace-nowrap">
            Explore Services
          </a>
          <a href="portfolio.php" class="inline-block bg-transparent text-white border border-white px-8 py-3 rounded-lg whitespace-nowrap">
            View Our Work
          </a>
        </div>
      </div>

      <!-- Right side: preview / visual + vertical nav (col-span 5) -->
      <div class="lg:col-span-5 col-span-1">
        <div class="relative rounded-xl overflow-hidden shadow-2xl h-64 md:h-80 lg:h-96 ring-1 ring-black/20 bg-black/20">
          <!-- small preview area inside container, JS will inject preview image here (keeps aspect) -->
          <div id="preview" class="absolute inset-0 w-full h-full"></div>
          <!-- vertical nav over the preview (right) -->
          <div id="slider-nav" class="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col items-center space-y-4 z-30"></div>
        </div>
      </div>
    </div>

    <!-- Thumbnails row (inside same max-w-7xl canvas) -->
    <div id="service-thumbs" class="mt-10 flex gap-5 overflow-x-auto py-2 -mx-6 px-6 lg:px-0"></div>
  </div>

  <!-- Decorative gradient overlay to keep contrast (covers full section) -->
  <div class="absolute inset-0 bg-gradient-to-b from-[#0042AA]/60 to-[#0042AA]/90 z-10 pointer-events-none"></div>

  <!-- Slides Data & JS -->
  <script>
    // Slides metadata (update paths/text as needed)
    const slides = [
      {
        bg: 'assets/slider/hero-s-1.jpg',
        title: 'Cloud Infrastructure & Security',
        desc: 'Industry-leading managed cloud, data protection, and IT security for modern businesses. Scalable, safe, and always-on solutions tailored for growth.',
        thumb: 'assets/slider/hero-s-1.jpg',
        thumbTitle: 'Cloud Infrastructure'
      },
      {
        bg: 'assets/slider/hero-s-2.jpg',
        title: 'Digital Transformation',
        desc: 'Accelerate your digital journey with automation, custom software, and agile IT consulting for forward-looking enterprises.',
        thumb: 'assets/slider/hero-s-2.jpg',
        thumbTitle: 'Digital Transformation'
      },
      {
        bg: 'assets/slider/hero-s-3.jpg',
        title: 'Managed IT Services',
        desc: 'End-to-end IT management, monitoring, and support to ensure maximum uptime, security, and operational efficiency.',
        thumb: 'assets/slider/hero-s-3.jpg',
        thumbTitle: 'Managed IT'
      },
      {
        bg: 'assets/slider/hero-s-4.jpg',
        title: 'Cybersecurity & Compliance',
        desc: 'Proactive threat hunting, vulnerability management, and compliance for peace of mind and regulatory alignment.',
        thumb: 'assets/slider/hero-s-4.jpg',
        thumbTitle: 'Cybersecurity'
      }
    ];

    // DOM refs
    const heroBg = document.getElementById('hero-bg');
    const preview = document.getElementById('preview');
    const navContainer = document.getElementById('slider-nav');
    const titleEl = document.getElementById('slide-title');
    const descEl = document.getElementById('slide-desc');
    const thumbsEl = document.getElementById('service-thumbs');
    const heroSection = document.getElementById('hero-services');

    let current = 0;
    let intervalId = null;
    const AUTO_DELAY = 4500;
    const TRANSITION_MS = 700;

    // Utility: create background image (covers full section, not limited by canvas)
    function setBackgroundImage(src) {
      // fade between background images
      const nextImg = document.createElement('img');
      nextImg.src = src;
      nextImg.alt = '';
      nextImg.className = `absolute inset-0 w-full h-full object-cover transition-opacity duration-700 opacity-0`;
      heroBg.appendChild(nextImg);

      // force repaint then fade in
      requestAnimationFrame(() => nextImg.classList.remove('opacity-0'));

      // remove older images (keep only 2 max)
      const imgs = heroBg.querySelectorAll('img');
      if (imgs.length > 2) {
        imgs[0].remove();
      }
    }

    // Utility: set preview image inside the canvas preview box (keeps object-cover)
    function setPreviewImage(src, alt = '') {
      preview.innerHTML = '';
      const img = document.createElement('img');
      img.src = src;
      img.alt = alt;
      img.className = 'w-full h-full object-cover';
      preview.appendChild(img);
    }

    // Render current slide into the content canvas
    function renderSlide(idx) {
      const s = slides[idx];

      // background fills whole section
      setBackgroundImage(s.bg);

      // left content
      titleEl.textContent = s.title;
      descEl.textContent = s.desc;

      // preview image (inside max-w-7xl canvas)
      setPreviewImage(s.thumb || s.bg, s.thumbTitle || s.title);

      // navigation dots (vertical)
      navContainer.innerHTML = slides.map((_, i) => {
        const active = i === idx;
        return `
          <button
            aria-label="Go to slide ${i + 1}"
            data-index="${i}"
            class="w-10 h-10 flex items-center justify-center rounded-full ${active ? 'ring-2 ring-blue-400 bg-white/20' : 'bg-white/30 hover:scale-105'} transition-transform"
          >
            ${active ? '<span class="w-3 h-3 bg-[#00AAE4] rounded-full"></span>' : '<span class="w-2 h-2 bg-white rounded-full opacity-80"></span>'}
          </button>
        `;
      }).join('');

      // thumbnails list (inside canvas)
      thumbsEl.innerHTML = slides.map((t, i) => {
        const activeClass = i === idx ? 'ring-2 ring-[#00AAE4] scale-105' : 'ring-0';
        return `
          <button data-index="${i}" class="min-w-[14rem] w-56 flex-shrink-0 bg-white/5 backdrop-blur-sm rounded-xl overflow-hidden shadow-md border ${activeClass} transition-transform transform hover:-translate-y-1">
            <img src="${t.thumb}" alt="${t.thumbTitle}" class="w-full h-32 object-cover" />
            <div class="p-3 text-left">
              <h3 class="font-semibold text-white text-lg">${t.thumbTitle}</h3>
            </div>
          </button>
        `;
      }).join('');
      // attach event listeners to new controls
      attachControls();
    }

    // navigate to slide
    function goSlide(idx) {
      current = idx;
      renderSlide(current);
      resetAutoSlide();
    }

    // attach click handlers for nav dots & thumbnails (delegation)
    function attachControls() {
      // vertical dots
      navContainer.querySelectorAll('button[data-index]').forEach(btn => {
        btn.onclick = () => goSlide(Number(btn.dataset.index));
      });
      // thumbnails
      thumbsEl.querySelectorAll('button[data-index]').forEach(btn => {
        btn.onclick = () => goSlide(Number(btn.dataset.index));
      });
    }

    // Auto slide start / reset / stop
    function startAutoSlide() {
      stopAutoSlide();
      intervalId = setInterval(() => {
        current = (current + 1) % slides.length;
        renderSlide(current);
      }, AUTO_DELAY);
    }
    function stopAutoSlide() {
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
    }
    function resetAutoSlide() {
      startAutoSlide();
    }

    // Pause on hover/focus for accessibility
    heroSection.addEventListener('mouseenter', stopAutoSlide);
    heroSection.addEventListener('mouseleave', startAutoSlide);
    heroSection.addEventListener('focusin', stopAutoSlide);
    heroSection.addEventListener('focusout', startAutoSlide);

    // keyboard controls
    window.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') {
        goSlide((current + 1) % slides.length);
      } else if (e.key === 'ArrowLeft') {
        goSlide((current - 1 + slides.length) % slides.length);
      }
    });

    // Initial render and start auto
    renderSlide(current);
    startAutoSlide();
    // Ensure background has a baseline blank image to avoid layout shift if needed
    if (!heroBg.querySelector('img')) setBackgroundImage(slides[0].bg);
  </script>
</section>



    <!-- Hero Section >
    <section class="hero-bg min-h-screen flex items-center" id="flex-screen">
      <div class="container mx-auto px-4 py-20 md:py-0">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div class="fade-in">
            <h1
              class="text-4xl md:text-6xl font-bold text-white leading-tight mb-6"
            >
              <span class="block">Web Development</span>
              <span class="block">Company &</span>
              <span class="block">Digital Agency</span>
            </h1>
            <p class="text-white text-lg md:text-xl mb-8 opacity-90">
              We transform your digital vision into reality with cutting-edge
              web development and strategic digital marketing solutions.
            </p>
            <div class="flex flex-col sm:flex-row gap-4">
              <a
                href="#services"
                class="btn-primary text-white px-8 py-3 text-center !rounded-button whitespace-nowrap"
              >
                Explore Services
              </a>
              <a
                href="#portfolio"
                class="btn-outline bg-white text-primary px-8 py-3 text-center border-2 border-white !rounded-button whitespace-nowrap"
              >
                View Our Work
              </a>
            </div>
          </div>
          <div class="hidden md:block">
            <img
              src="images/hero-4.jpeg"
              alt="Web Development and Digital Agency"
              class="w-full h-auto rounded-lg shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section-->

<!-- Services Section >
<section id="services" class="py-20 bg-gray-50">
  <div class="container mx-auto px-4">
    <div class="text-center mb-16">
      <h2 class="text-3xl md:text-4xl font-bold mb-4">Our Premium Services</h2>
      <p class="text-gray-600 max-w-2xl mx-auto">
        We offer comprehensive digital solutions tailored to your business
        needs, combining technical expertise with creative innovation.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      
      <!-- Card 1 - Mascot from LEFT >
      <div class="relative group bg-white hover:bg-blue-600 transition-all duration-500 rounded-2xl shadow-lg overflow-hidden p-6 w-full h-full">
        <img src="images/mascot.png"
             class="absolute right-[-163px] top-1/2 -translate-y-1/2 w-24 transition-all duration-500 group-hover:right-[-6px] z-10"
             alt="Mascot from left" id="mascot">
        <div class="relative z-20">
          <div class="w-14 h-14 flex items-center justify-center rounded-full bg-blue-100 mb-6">
            <i class="ri-code-s-slash-line ri-2x text-blue-600"></i>
          </div>
          <h3 class="text-xl font-semibold mb-2 group-hover:text-white transition">Web Development with AI</h3>
          <p class="text-gray-600 group-hover:text-white transition">
            - WordPress, Laravel, APIs -
          </p>
            <p class="text-gray-600 group-hover:text-white transition">
              Custom websites and applications built with cutting-edge
              technologies and AI-driven solutions for optimal performance.
            </p>
          <a href="#" class="mt-4 inline-flex items-center font-medium text-blue-600 group-hover:text-white transition">
            Explore <i class="ri-arrow-right-line ml-2"></i>
          </a>
        </div>
      </div>
	  
      <!-- Card 2 - Mascot from LEFT >
      <div class="relative group bg-white hover:bg-blue-600 transition-all duration-500 rounded-2xl shadow-lg overflow-hidden p-6 w-full h-full">
        <img src="images/mascot.png"
             class="absolute right-[-163px] top-1/2 -translate-y-1/2 w-24 transition-all duration-500 group-hover:right-[-6px] z-10"
             alt="Mascot from left" id="mascot">
        <div class="relative z-20">
          <div class="w-14 h-14 flex items-center justify-center rounded-full bg-blue-100 mb-6">
            <i class="ri-line-chart-line ri-2x text-blue-600"></i>
          </div>
          <h3 class="text-xl font-semibold mb-2 group-hover:text-white transition">Digital Marketing with AI</h3>
          <p class="text-gray-600 group-hover:text-white transition">
            - UX, SEO, Ads, Automation -
          </p>
            <p class="text-gray-600 group-hover:text-white transition">
              Data-driven marketing strategies powered by AI to maximize your
              online presence and drive measurable results.
            </p>
          <a href="#" class="mt-4 inline-flex items-center font-medium text-blue-600 group-hover:text-white transition">
            Explore <i class="ri-arrow-right-line ml-2"></i>
          </a>
        </div>
      </div>
      <!-- Card 3 - Mascot from LEFT >
      <div class="relative group bg-white hover:bg-blue-600 transition-all duration-500 rounded-2xl shadow-lg overflow-hidden p-6 w-full h-full">
        <img src="images/mascot.png"
             class="absolute right-[-163px] top-1/2 -translate-y-1/2 w-24 transition-all duration-500 group-hover:right-[-6px] z-10"
             alt="Mascot from left" id="mascot">
        <div class="relative z-20">
          <div class="w-14 h-14 flex items-center justify-center rounded-full bg-blue-100 mb-6">
            <i class="ri-settings-line ri-2x text-blue-600"></i>
          </div>
          <h3 class="text-xl font-semibold mb-2 group-hover:text-white transition">Industry Tech Solutions</h3>
          <p class="text-gray-600 group-hover:text-white transition">
            - Travel, Education, Healthcare -
          </p>
            <p class="text-gray-600 group-hover:text-white transition">
              Specialized technology solutions designed for specific industry
              needs, from healthcare to finance and beyond.
            </p>
          <a href="#" class="mt-4 inline-flex items-center font-medium text-blue-600 group-hover:text-white transition">
            Explore <i class="ri-arrow-right-line ml-2"></i>
          </a>
        </div>
      </div>
      <!-- Card 4 - Mascot from LEFT >
      <div class="relative group bg-white hover:bg-blue-600 transition-all duration-500 rounded-2xl shadow-lg overflow-hidden p-6 w-full h-full">
        <img src="images/mascot.png"
             class="absolute right-[-163px] top-1/2 -translate-y-1/2 w-24 transition-all duration-500 group-hover:right-[-6px] z-10"
             alt="Mascot from left" id="mascot">
        <div class="relative z-20">
          <div class="w-14 h-14 flex items-center justify-center rounded-full bg-blue-100 mb-6">
            <i class="ri-palette-line ri-2x text-blue-600"></i>
          </div>
          <h3 class="text-xl font-semibold mb-2 group-hover:text-white transition">Graphic Design Services</h3>
          <p class="text-gray-600 group-hover:text-white transition">
            - Web Design, Social Media -
          </p>
            <p class="text-gray-600 group-hover:text-white transition">
              Creative design solutions that captivate your audience, from
              branding and logos to UI/UX design and print materials.
            </p>
          <a href="#" class="mt-4 inline-flex items-center font-medium text-blue-600 group-hover:text-white transition">
            Explore <i class="ri-arrow-right-line ml-2"></i>
          </a>
        </div>
      </div>

      <!-- Repeat this structure for other services below with different icons and text -->
      <!-- Example: Digital Marketing, Industry Tech Solutions, Graphic Design Services -->
      <!-- Change icon and text content inside as needed -->
      
    <!--/div>
  </div>
</section-->


<section class="w-full bg-[#fff] py-16">
  <div class="max-w-7xl mx-auto flex flex-col lg:flex-row gap-12 px-6 items-start">
    <!-- Left: Feature Cards and Title -->
    <div class="flex-1">
      <div class="flex items-center gap-2 mb-3">
        <svg class="w-5 h-5 text-[#00AAE4]" fill="currentColor" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" /></svg>
        <span class="font-semibold uppercase tracking-wide text-lg">Why Choose Us</span>
      </div>
      <h2 class="text-4xl font-bold mb-7 text-[#18191F]">Why We're Different</h2>
      <div class="space-y-6">
        <!-- Card 1 -->
        <div class="rounded-xl border border-[#ECECEC] bg-white p-6 shadow-sm hover:shadow-xl transition duration-300 animate-fade-in" style="animation-delay:0.1s">
          <div class="font-semibold text-lg mb-2 text-[#18191F]">Data-Driven Approach</div>
          <div class="text-[#363745] text-base">We harness advanced analytics and insights to craft strategies that ensure impactful and efficient digital marketing solutions.</div>
        </div>
        <!-- Card 2 -->
        <div class="rounded-xl border border-[#ECECEC] bg-white p-6 shadow-sm hover:shadow-xl transition duration-300 animate-fade-in" style="animation-delay:0.2s">
          <div class="font-semibold text-lg mb-2 text-[#18191F]">Competitive Pricing</div>
          <div class="text-[#363745] text-base">Our services combine premium quality with affordability, offering exceptional value to help businesses thrive on any budget.</div>
        </div>
        <!-- Card 3 -->
        <div class="rounded-xl border border-[#ECECEC] bg-white p-6 shadow-sm hover:shadow-xl transition duration-300 animate-fade-in" style="animation-delay:0.3s">
          <div class="font-semibold text-lg mb-2 text-[#18191F]">Ethical Business Practices</div>
          <div class="text-[#363745] text-base">We uphold the highest standards of integrity, professionalism, and ethical practices in every aspect of our work for our clients.</div>
        </div>
      </div>
      <!-- CTA Button -->
      <a href="#contact" class="mt-8 inline-block px-9 py-4 bg-[#256eff] text-white font-bold rounded-full shadow text-lg transition duration-300 hover:bg-[#00AAE4] hover:text-white animate-scale-up" style="animation-delay:0.4s">
        Contact Us
      </a>
    </div>
    <!-- Right: Description + Image -->
    <div class="flex-1 flex flex-col items-center lg:items-end gap-5">
      <p class="text-lg text-[#363745] mb-5 max-w-xl animate-slide-up" style="animation-delay:0.13s">
        We don’t just market your brand; we create lasting impressions that drive results. Our team of seasoned experts blends creativity with cutting-edge technology to design your unique goals.
      </p>
      <div class="relative animate-pop-in" style="animation-delay:0.2s">
        <img src="assets/choose4-image-768x728.webp" alt="Event Speaker" class="rounded-2xl w-[574px] h-[400px] object-cover shadow-lg">
        <span class="absolute top-[-40px] right-[-40px] w-24 h-24">
          <!-- Decorative illustration/icon as PNG/SVG -->
          <img src="assets/hero4-sec-shape2.webp" alt="Icon">
        </span>
      </div>
    </div>
  </div>
  <style>
    @keyframes fade-in {
      from {opacity:0;transform:translateY(25px);}
      to {opacity:1;transform:translateY(0);}
    }
    @keyframes slide-up { from {opacity:0;transform:translateY(40px);} to {opacity:1;transform:translateY(0);} }
    @keyframes scale-up { from {opacity:0;transform:scale(0.93);} to {opacity:1;transform:scale(1);} }
    @keyframes pop-in { from {opacity:0;transform:scale(0.93) rotate(-10deg);} to {opacity:1;transform:scale(1) rotate(0deg);} }
    .animate-fade-in{animation:fade-in 1s cubic-bezier(.57,1.42,.33,.99) forwards;}
    .animate-slide-up{animation:slide-up 0.9s cubic-bezier(.57,1.42,.33,.99) forwards;}
    .animate-scale-up{animation:scale-up 1.1s cubic-bezier(.57,1.42,.33,.99) forwards;}
    .animate-pop-in {animation:pop-in 1.15s cubic-bezier(.57,1.42,.33,.99) forwards;}
  </style>
</section>

<section class="py-20 w-full items-center justify-center overflow-hidden bg-[#0042AA] text-white">
    
  <!-- Animated SVG Background -->
  <svg class="absolute inset-0 w-full h-full z-0 pointer-events-none" aria-hidden="true">
    <defs>
      <linearGradient id="heroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop stop-color="#00AAE4" stop-opacity="0.25"/>
        <stop stop-color="#0042AA" stop-opacity="1"/>
      </linearGradient>
    </defs>
    <rect width="100%" height="100%" fill="url(#heroGradient)"/>
    <g>
      <animateTransform attributeName="transform" type="translate" values="0 0;50 0;0 0" dur="4s" repeatCount="indefinite" />
      <path d="M 80 0 L 100 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
      <path d="M 300 0 L 500 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
      <path d="M 700 0 L 900 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
    </g>
  </svg>
  <div class="max-w-7xl mx-auto text-center mb-3">
    <span class="inline-block bg-gray-100 text-gray-700 px-4 py-1 rounded-full font-semibold text-sm mb-4 tracking-widest">
      <svg class="inline-block w-4 h-4 text-[#00AAE4] mr-1 -mt-1" fill="currentColor" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" /></svg>
      FROM STRATEGY TO SUCCESS
    </span>
    <h2 class="text-3xl md:text-4xl font-extrabold tracking-tight mb-10 text-white">
      Simple Steps to Big Results
    </h2>
  </div>
  <div class="max-w-6xl mx-auto flex flex-col md:flex-row items-start justify-center gap-6 md:gap-10 relative">

    <!-- Steps Bar (dashed line + numbers) -->
    <div class="absolute left-0 right-0 top-7 md:top-6 z-0">
      <div class="w-full h-4 relative">
        <div class="border-t-2 border-dashed border-gray-300 absolute top-1/2 left-[15%] right-[15%]"></div>
      </div>
    </div>

    <!-- Timeline Bar -->
<div class="absolute left-0 right-0 top-7 md:top-6 z-0 pointer-events-none">
  <div class="w-full h-4 relative">
    <div class="border-t-2 border-dashed border-gray-300 absolute top-1/2 left-[16%] right-[16%]"></div>
  </div>
</div>

<!-- Step 1: Active Blue -->
<div class="relative z-10 flex-1 group">
  <div class="flex flex-col items-center">
    <span class="w-14 h-14 flex items-center justify-center rounded-full border-2 border-[#0042AA] bg-white text-[#0042AA] text-xl font-bold shadow transition group-hover:bg-[#0042AA] group-hover:text-white group-hover:border-white">01</span>
  </div>
  <div class="relative mt-8 bg-[#F6F7FF] group-hover:bg-[#0042AA] group-hover:text-white text-[#11142b] rounded-2xl shadow transition-all duration-300 pt-10 pb-7 px-8 text-center max-w-xs mx-auto">
    <h3 class="text-xl font-bold mb-3">Discovery, Strategy And Planning</h3>
    <p class="text-base font-medium opacity-95">We start with a deep dive into your brand, audience, and goals based</p>
  </div>
</div>

<!-- Step 2 -->
<div class="relative z-10 flex-1 group">
  <div class="flex flex-col items-center">
    <span class="w-14 h-14 flex items-center justify-center rounded-full border-2 border-gray-200 bg-white text-[#22223b] text-xl font-bold shadow transition group-hover:bg-[#0042AA] group-hover:text-white group-hover:border-white">02</span>
  </div>
  <div class="relative mt-8 bg-[#F6F7FF] group-hover:bg-[#0042AA] group-hover:text-white text-[#11142b] rounded-2xl shadow transition-all duration-300 pt-10 pb-7 px-8 text-center max-w-xs mx-auto">
    <h3 class="text-xl font-bold mb-3">Paid Campaigns (Optional)</h3>
    <p class="text-base font-medium opacity-90">Want to scale fast? We set up and manage target ad campaign grow</p>
  </div>
</div>

<!-- Step 3 -->
<div class="relative z-10 flex-1 group">
  <div class="flex flex-col items-center">
    <span class="w-14 h-14 flex items-center justify-center rounded-full border-2 border-gray-200 bg-white text-[#22223b] text-xl font-bold shadow transition group-hover:bg-[#0042AA] group-hover:text-white group-hover:border-white">03</span>
  </div>
  <div class="relative mt-8 bg-[#F6F7FF] group-hover:bg-[#0042AA] group-hover:text-white text-[#11142b] rounded-2xl shadow transition-all duration-300 pt-10 pb-7 px-8 text-center max-w-xs mx-auto">
    <h3 class="text-xl font-bold mb-3">Monitor Analyze Improve</h3>
    <p class="text-base font-medium opacity-90">With regular reporting, insights, and tweaks, we make sure your content levels up</p>
  </div>
</div>
</section>

<!-- Services / CTA Section (uses Tailwind; ensure Tailwind CDN is in your header) -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-6 lg:px-8">
    <div class="grid grid-cols-1 lg:grid-cols-12 items-center gap-8">

      <!-- Left: Overlapping Image Cards -->
      <div class="lg:col-span-6 col-span-1 flex justify-center lg:justify-start">
        <div class="relative w-[360px] sm:w-[420px] lg:w-[520px] h-[340px] lg:h-[360px]">
          <!-- Back card -->
          <div class="absolute left-0 top-8 lg:top-12 w-60 sm:w-64 lg:w-72 h-60 sm:h-64 lg:h-72 rounded-xl overflow-hidden shadow-2xl transform rotate-[2deg] bg-white">
            <img src="assets/home-default-img-1.png" alt="service image back" class="w-full h-full object-cover"/>
          </div>

          <!-- Front card -->
          <div class="absolute left-20 lg:left-28 top-0 w-64 sm:w-72 lg:w-80 h-64 sm:h-72 lg:h-80 rounded-xl overflow-hidden shadow-2xl ring-1 ring-black/5 bg-white">
            <img src="assets/home-default-img-2.png" alt="service image front" class="w-full h-full object-cover"/>
          </div>

          <!-- Subtle large vignette / soft shadow for depth -->
          <div class="absolute inset-0 pointer-events-none">
            <div class="absolute -left-10 -bottom-8 w-[260px] h-[260px] bg-gradient-to-br from-black/6 to-transparent rounded-full blur-3xl opacity-60"></div>
          </div>
        </div>
      </div>

      <!-- Right: Text Content -->
      <div class="lg:col-span-6 col-span-1">
        <p class="text-sm text-blue-600 uppercase tracking-wider mb-3">Need Help With Our Services</p>
        <h2 class="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 mb-4 leading-tight">
          Are You Looking For <span class="text-blue-600">Our Services?</span>
        </h2>
        <p class="text-sm sm:text-base text-slate-600 mb-6 max-w-xl">
          <strong class="text-slate-800">All your business solutions at one place.</strong>
          Elevate your business with our innovative solutions, crafted to seamlessly integrate cutting-edge technology,
          enhance operational efficiency, and drive sustainable growth. Experience a tailored approach to meet your unique needs.
        </p>

        <div class="flex flex-col sm:flex-row gap-3">
          <a href="contact.php" class="inline-flex items-center justify-center px-6 py-3 rounded-full bg-blue-800 text-white text-sm font-semibold shadow-md hover:bg-blue-900 transition">
            LET'S DISCUSS YOUR PROJECT IN DETAILS
          </a>
          <a href="services.php" class="inline-flex items-center justify-center px-6 py-3 rounded-full border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50 transition">
            View Services
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- Core Industries Section -->
<section class="py-20 w-full items-center justify-center overflow-hidden bg-[#0042AA] text-white">
  <div class="max-w-7xl mx-auto px-6 lg:px-8 text-center">

    <!-- Heading -->
    <h2 class="text-3xl md:text-4xl font-extrabold text-white-900 mb-4">
      Solving Complex Challenges Across Core Industries
    </h2>
    <p class="text-white-600 max-w-3xl mx-auto mb-12">
      From regulatory complexity to customer behavior, our deep domain knowledge ensures every solution is technically sound and business-ready.
    </p>

    <!-- Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
      
      <!-- Industry Card -->
      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-graduation-cap text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Education</span>
      </div>
      
      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-regular fa-heart text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Healthcare</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-cart-shopping text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">eCommerce</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-car-battery text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Electric Vehicle (EV)</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-plane text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Travel</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-share-nodes text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Social Media</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-dollar-sign text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Finance</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-truck text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Logistics</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-music text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Entertainment</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-house text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Real Estate</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-plane-departure text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Aviation</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-droplet text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Oil & Gas</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-car text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Automotive</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-shield-halved text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Insurance</span>
      </div>

      <div class="flex items-center gap-3 bg-white border border-gray-100 shadow-[0_3px_10px_rgba(0,0,0,0.04)] rounded-full px-6 py-4 hover:shadow-[0_6px_18px_rgba(0,0,0,0.08)] transition">
        <i class="fa-solid fa-industry text-xl text-blue-700"></i>
        <span class="text-slate-800 font-medium">Manufacturing</span>
      </div>
    </div>

  </div>
</section>

<section class="bg-[#F9F8F6] py-20">
  <div class="max-w-7xl mx-auto px-6 lg:px-8">

    <!-- Header / Intro -->
    <div class="text-center mb-12">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 mb-4">
        What Makes Us Stand Out
      </h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">
        We combine deep domain expertise, cutting-edge technology, and a customer-first approach to deliver robust solutions across every industry.
      </p>
    </div>

    <!-- Feature Cards Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      <!-- Card 1 -->
      <div class="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition group">
        <div class="w-12 h-12 mb-4 text-blue-600">
          <!-- Put icon here (SVG or <i>) -->
          <i class="fa-solid fa-lightbulb text-2xl"></i>
        </div>
        <h3 class="text-xl font-semibold text-slate-900 mb-2 group-hover:text-blue-600">
          Innovation & Strategy
        </h3>
        <p class="text-slate-600">
          We bring fresh ideas and strategic insights to help your business stay ahead of the curve.
        </p>
      </div>

      <!-- Card 2 -->
      <div class="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition group">
        <div class="w-12 h-12 mb-4 text-blue-600">
          <i class="fa-solid fa-cogs text-2xl"></i>
        </div>
        <h3 class="text-xl font-semibold text-slate-900 mb-2 group-hover:text-blue-600">
          Technical Excellence
        </h3>
        <p class="text-slate-600">
          Our team ensures all solutions are optimized, secure, and built using best practices.
        </p>
      </div>

      <!-- Card 3 -->
      <div class="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition group">
        <div class="w-12 h-12 mb-4 text-blue-600">
          <i class="fa-solid fa-handshake text-2xl"></i>
        </div>
        <h3 class="text-xl font-semibold text-slate-900 mb-2 group-hover:text-blue-600">
          Client Partnership
        </h3>
        <p class="text-slate-600">
          We work closely with you, aligning goals and strategies to maximize outcome.
        </p>
      </div>

      <!-- More cards if needed... -->
    </div>

    <!-- CTA Button -->
    <div class="mt-12 text-center">
      <a href="contact.php" class="inline-block bg-blue-800 text-white px-8 py-3 rounded-full text-lg font-medium hover:bg-blue-900 transition">
        Get Started with Us
      </a>
    </div>

  </div>
</section>

<!-- Case Studies / Recent Projects - Swiper Carousel -->
<section class="overflow-hidden bg-[#0042AA] text-white py-24">
  <div class="max-w-7xl mx-auto px-6 lg:px-8">
    
    <!-- Section Header -->
    <div class="text-center mb-16">
      <h2 class="text-4xl md:text-5xl font-extrabold text-white mb-4">Recent Projects</h2>
      <p class="text-lg text-white max-w-2xl mx-auto">
        Discover how Redes Creation delivers scalable, secure, and creative digital solutions across diverse industries.
      </p>
    </div>

    <!-- Swiper Container -->
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">

        <!-- Project 1 -->
        <div class="swiper-slide">
          <div class="relative group overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500">
            <img src="assets/uni-web.png" alt="University Website" class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-700">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div class="absolute bottom-6 left-6 text-white opacity-0 group-hover:opacity-100 transition-all duration-500">
              <h3 class="text-xl font-semibold">Dynamic University Website</h3>
              <p class="text-sm text-gray-200 mb-2">Education Sector</p>
              <button onclick="openModal('case1')" class="px-4 py-2 bg-blue-700 text-white rounded-full text-sm hover:bg-blue-800 transition">View Case</button>
            </div>
          </div>
        </div>

        <!-- Project 2 -->
        <div class="swiper-slide">
          <div class="relative group overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500">
            <img src="assets/erp.png" alt="ERP Solution" class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-700">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div class="absolute bottom-6 left-6 text-white opacity-0 group-hover:opacity-100 transition-all duration-500">
              <h3 class="text-xl font-semibold">Smart ERP Implementation</h3>
              <p class="text-sm text-gray-200 mb-2">Automation & Tech</p>
              <button onclick="openModal('case2')" class="px-4 py-2 bg-blue-700 text-white rounded-full text-sm hover:bg-blue-800 transition">View Case</button>
            </div>
          </div>
        </div>

        <!-- Project 3 -->
        <div class="swiper-slide">
          <div class="relative group overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500">
            <img src="assets/hms.jpg" alt="Hospital Management System" class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-700">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div class="absolute bottom-6 left-6 text-white opacity-0 group-hover:opacity-100 transition-all duration-500">
              <h3 class="text-xl font-semibold">Hospital Management System</h3>
              <p class="text-sm text-gray-200 mb-2">Healthcare Industry</p>
              <button onclick="openModal('case3')" class="px-4 py-2 bg-blue-700 text-white rounded-full text-sm hover:bg-blue-800 transition">View Case</button>
            </div>
          </div>
        </div>

        <!-- Project 4 -->
        <div class="swiper-slide">
          <div class="relative group overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500">
            <img src="assets/uni-web.png" alt="University Website" class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-700">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div class="absolute bottom-6 left-6 text-white opacity-0 group-hover:opacity-100 transition-all duration-500">
              <h3 class="text-xl font-semibold">Dynamic University Website</h3>
              <p class="text-sm text-gray-200 mb-2">Education Sector</p>
              <button onclick="openModal('case1')" class="px-4 py-2 bg-blue-700 text-white rounded-full text-sm hover:bg-blue-800 transition">View Case</button>
            </div>
          </div>
        </div>

        <!-- Project 5 -->
        <div class="swiper-slide">
          <div class="relative group overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500">
            <img src="assets/hms.jpg" alt="Hospital Management System" class="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-700">
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div class="absolute bottom-6 left-6 text-white opacity-0 group-hover:opacity-100 transition-all duration-500">
              <h3 class="text-xl font-semibold">Hospital Management System</h3>
              <p class="text-sm text-gray-200 mb-2">Healthcare Industry</p>
              <button onclick="openModal('case3')" class="px-4 py-2 bg-blue-700 text-white rounded-full text-sm hover:bg-blue-800 transition">View Case</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Swiper Controls -->
      <div class="swiper-pagination mt-8"></div>
    </div>
  </div>

  <!-- Lightbox Modals -->
  <div id="case1" class="hidden fixed inset-0 bg-black/80 flex items-center justify-center z-50">
    <div class="bg-white rounded-2xl max-w-2xl mx-4 p-8 relative animate-fadeIn">
      <button onclick="closeModal('case1')" class="absolute top-4 right-4 text-gray-600 hover:text-black text-xl">&times;</button>
      <h3 class="text-2xl font-semibold text-white mb-3">Dynamic University Website</h3>
      <p class="text-slate-700 mb-4">
        Redes Creation developed a complete dynamic, UGC-compliant, ERP-ready university website including admin CMS, live notifications, and enquiry-to-admission flow.
      </p>
      <img src="assets/uni-web.png" class="rounded-lg" alt="University Project" />
    </div>
  </div>

  <div id="case2" class="hidden fixed inset-0 bg-black/80 flex items-center justify-center z-50">
    <div class="bg-white rounded-2xl max-w-2xl mx-4 p-8 relative animate-fadeIn">
      <button onclick="closeModal('case2')" class="absolute top-4 right-4 text-gray-600 hover:text-black text-xl">&times;</button>
      <h3 class="text-2xl font-semibold text-white mb-3">Smart ERP Implementation</h3>
      <p class="text-slate-700 mb-4">
        Redes Creation implemented a full-fledged ERP system integrating Academics, HR, Accounts, and Admissions to optimize institution-wide operations.
      </p>
      <img src="assets/erp.png" class="rounded-lg" alt="ERP Project" />
    </div>
  </div>

  <div id="case3" class="hidden fixed inset-0 bg-black/80 flex items-center justify-center z-50">
    <div class="bg-white rounded-2xl max-w-2xl mx-4 p-8 relative animate-fadeIn">
      <button onclick="closeModal('case3')" class="absolute top-4 right-4 text-gray-600 hover:text-black text-xl">&times;</button>
      <h3 class="text-2xl font-semibold text-white mb-3">Hospital Management System</h3>
      <p class="text-slate-700 mb-4">
        Redes Creation built a hospital management solution with patient records, doctor scheduling, and billing automation with real-time analytics dashboards.
      </p>
      <img src="assets/hms.jpg" class="rounded-lg" alt="HMS Project" />
    </div>
  </div>
</section>

<!-- Swiper + Animation JS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<style>
  @keyframes fadeIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
  .animate-fadeIn { animation: fadeIn 0.3s ease-out; }
</style>

<script>
  // Swiper Config
  const swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 24,
    loop: true,
    grabCursor: true,
    centeredSlides: true,
    autoplay: { delay: 4000, disableOnInteraction: false },
    pagination: { el: ".swiper-pagination", clickable: true },
    breakpoints: {
      768: { slidesPerView: 2 },
      1024: { slidesPerView: 3 }
    }
  });

  // Modal functions
  function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
    document.body.classList.add('overflow-hidden');
  }
  function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
    document.body.classList.remove('overflow-hidden');
  }
</script>



<!-- HOW WE WORK SECTION -->
<section class="relative overflow-hidden bg-gradient-to-br from-white via-blue-50/30 to-blue-100/40 py-24">
  <div class="max-w-7xl mx-auto px-6 lg:px-8">
    
    <!-- Header -->
    <div class="text-center mb-20">
      <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-4">
        How <span class="text-blue-700">We Work</span>
      </h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">
        Our process is designed to simplify complexity and deliver excellence — from idea to execution.
      </p>
    </div>

    <!-- Timeline Steps -->
    <div class="relative">
      <!-- Line Connector -->
      <div class="absolute left-1/2 top-0 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-blue-400 via-blue-300 to-blue-100 rounded-full hidden md:block"></div>
      
      <div id="steps" class="space-y-20">
        <!-- STEP 1 -->
        <div class="relative md:flex items-center justify-between group opacity-0 translate-y-10 transition-all duration-700">
          <div class="md:w-5/12 text-center md:text-right">
            <h3 class="text-2xl font-semibold text-slate-900 mb-2">1. Consultation & Discovery</h3>
            <p class="text-slate-600">We begin by understanding your vision, goals, and challenges through a deep discovery session.</p>
          </div>
          <div class="w-16 h-16 flex items-center justify-center bg-blue-600 text-white rounded-full shadow-lg mx-auto md:mx-0 md:order-none order-first mb-6 md:mb-0">
            <i class="fa-solid fa-comments text-2xl"></i>
          </div>
        </div>

        <!-- STEP 2 -->
        <div class="relative md:flex items-center justify-between group opacity-0 translate-y-10 transition-all duration-700">
          <div class="w-16 h-16 flex items-center justify-center bg-blue-600 text-white rounded-full shadow-lg mx-auto md:mx-0 mb-6 md:mb-0">
            <i class="fa-solid fa-pencil-ruler text-2xl"></i>
          </div>
          <div class="md:w-5/12 text-center md:text-left">
            <h3 class="text-2xl font-semibold text-slate-900 mb-2">2. Planning & Strategy</h3>
            <p class="text-slate-600">We create a data-driven strategy, wireframes, and workflow that align with your business objectives.</p>
          </div>
        </div>

        <!-- STEP 3 -->
        <div class="relative md:flex items-center justify-between group opacity-0 translate-y-10 transition-all duration-700">
          <div class="md:w-5/12 text-center md:text-right">
            <h3 class="text-2xl font-semibold text-slate-900 mb-2">3. Design & Development</h3>
            <p class="text-slate-600">Our creative and technical teams collaborate to build user-centric designs with flawless functionality.</p>
          </div>
          <div class="w-16 h-16 flex items-center justify-center bg-blue-600 text-white rounded-full shadow-lg mx-auto md:mx-0 mb-6 md:mb-0">
            <i class="fa-solid fa-code text-2xl"></i>
          </div>
        </div>

        <!-- STEP 4 -->
        <div class="relative md:flex items-center justify-between group opacity-0 translate-y-10 transition-all duration-700">
          <div class="w-16 h-16 flex items-center justify-center bg-blue-600 text-white rounded-full shadow-lg mx-auto md:mx-0 mb-6 md:mb-0">
            <i class="fa-solid fa-vial text-2xl"></i>
          </div>
          <div class="md:w-5/12 text-center md:text-left">
            <h3 class="text-2xl font-semibold text-slate-900 mb-2">4. Testing & Quality Assurance</h3>
            <p class="text-slate-600">Every project undergoes rigorous QA testing to ensure it’s fast, secure, and bug-free before launch.</p>
          </div>
        </div>

        <!-- STEP 5 -->
        <div class="relative md:flex items-center justify-between group opacity-0 translate-y-10 transition-all duration-700">
          <div class="md:w-5/12 text-center md:text-right">
            <h3 class="text-2xl font-semibold text-slate-900 mb-2">5. Launch & Ongoing Support</h3>
            <p class="text-slate-600">We ensure a smooth launch and provide continuous maintenance, upgrades, and performance monitoring.</p>
          </div>
          <div class="w-16 h-16 flex items-center justify-center bg-blue-600 text-white rounded-full shadow-lg mx-auto md:mx-0 mb-6 md:mb-0">
            <i class="fa-solid fa-rocket text-2xl"></i>
          </div>
        </div>
      </div>
    </div>

    <!-- CTA -->
    <div class="text-center mt-20">
      <a href="#contact" class="bg-blue-700 hover:bg-blue-800 text-white font-semibold px-10 py-4 rounded-full text-lg transition-all shadow-md hover:shadow-lg">
        Let’s Build Together
      </a>
    </div>
  </div>

  <!-- Subtle Animated Background Circles -->
  <div class="absolute top-10 left-10 w-32 h-32 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse"></div>
  <div class="absolute bottom-10 right-10 w-48 h-48 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-ping"></div>
</section>

<!-- ANIMATION JS -->
<script>
  const steps = document.querySelectorAll('#steps > div');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('opacity-100', 'translate-y-0');
        entry.target.classList.remove('opacity-0', 'translate-y-10');
      }
    });
  }, { threshold: 0.3 });

  steps.forEach(step => observer.observe(step));
</script>




    <!-- Portfolio Section >
    <section id="portfolio" class="py-20">
      <div class="container mx-auto px-4">
        <div class="text-center mb-16">
          <h2 class="text-3xl md:text-4xl font-bold mb-4">
            Our Recent Projects
          </h2>
          <p class="text-gray-600 max-w-2xl mx-auto">
            Explore our diverse portfolio of successful projects across various
            industries and digital platforms.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <!-- Portfolio Item 1 >
          <div
            class="portfolio-item relative rounded-lg overflow-hidden shadow-lg"
          >
            <img
              src="images/project1.jpg"
              alt="E-commerce Website"
              class="w-full h-64 object-cover"
            />
            <div class="portfolio-overlay">
              <div class="text-center text-white p-4">
                <h3 class="text-xl font-semibold mb-2">
                  Luxury E-commerce Platform
                </h3>
                <p class="mb-4">Web Development, UI/UX Design</p>
                <a
                  href="project1.php"
                  class="inline-block bg-white text-primary px-4 py-2 rounded-full"
                  >View Project</a
                >
              </div>
            </div>
          </div>

          <!-- Portfolio Item 2 >
          <div
            class="portfolio-item relative rounded-lg overflow-hidden shadow-lg"
          >
            <img
              src="images/project2.jpg"
              alt="Financial App"
              class="w-full h-64 object-cover"
            />
            <div class="portfolio-overlay">
              <div class="text-center text-white p-4">
                <h3 class="text-xl font-semibold mb-2">
                  FinTech Mobile Application
                </h3>
                <p class="mb-4">Mobile Development, UI/UX Design</p>
                <a
                  href="project2.php"
                  class="inline-block bg-white text-primary px-4 py-2 rounded-full"
                  >View Project</a
                >
              </div>
            </div>
          </div>

          <!-- Portfolio Item 3 >
          <div
            class="portfolio-item relative rounded-lg overflow-hidden shadow-lg"
          >
            <img
              src="images/project3.jpg"
              alt="Marketing Campaign"
              class="w-full h-64 object-cover"
            />
            <div class="portfolio-overlay">
              <div class="text-center text-white p-4">
                <h3 class="text-xl font-semibold mb-2">
                  Digital Marketing Campaign
                </h3>
                <p class="mb-4">SEO, Social Media Marketing</p>
                <a
                  href="projet3.php"
                  class="inline-block bg-white text-primary px-4 py-2 rounded-full"
                  >View Project</a
                >
              </div>
            </div>
          </div>

          <!-- Portfolio Item 4 >
          <div
            class="portfolio-item relative rounded-lg overflow-hidden shadow-lg"
          >
            <img
              src="images/project4.jpg"
              alt="Healthcare Portal"
              class="w-full h-64 object-cover"
            />
            <div class="portfolio-overlay">
              <div class="text-center text-white p-4">
                <h3 class="text-xl font-semibold mb-2">
                  Healthcare Patient Portal
                </h3>
                <p class="mb-4">Web Development, UX Research</p>
                <a
                  href="project4.php"
                  class="inline-block bg-white text-primary px-4 py-2 rounded-full"
                  >View Project</a
                >
              </div>
            </div>
          </div>

          <!-- Portfolio Item 5 >
          <div
            class="portfolio-item relative rounded-lg overflow-hidden shadow-lg"
          >
            <img
              src="images/project5.jpg"
              alt="Corporate Branding"
              class="w-full h-64 object-cover"
            />
            <div class="portfolio-overlay">
              <div class="text-center text-white p-4">
                <h3 class="text-xl font-semibold mb-2">Corporate Rebranding</h3>
                <p class="mb-4">Branding, Graphic Design</p>
                <a
                  href="project5.php"
                  class="inline-block bg-white text-primary px-4 py-2 rounded-full"
                  >View Project</a
                >
              </div>
            </div>
          </div>

          <!-- Portfolio Item 6 >
          <div
            class="portfolio-item relative rounded-lg overflow-hidden shadow-lg"
          >
            <img
              src="images/project6.jpg"
              alt="E-Learning Platform"
              class="w-full h-64 object-cover"
            />
            <div class="portfolio-overlay">
              <div class="text-center text-white p-4">
                <h3 class="text-xl font-semibold mb-2">E-Learning Platform</h3>
                <p class="mb-4">Web Development, Content Strategy</p>
                <a
                  href="project6.php"
                  class="inline-block bg-white text-primary px-4 py-2 rounded-full"
                  >View Project</a
                >
              </div>
            </div>
          </div>
        </div>

        <div class="text-center mt-12">
          <a
            href="#"
            class="btn-primary text-white px-8 py-3 !rounded-button whitespace-nowrap"
          >
            View All Projects
          </a>
        </div>
      </div>
    </section-->
    


    
	
	<!-- Portfolio Section >
<section id="portfolio" class="py-20 bg-gray-50">
<div class="container mx-auto px-4">
<div class="text-center mb-16 fade-in">
<h2 class="text-3xl md:text-4xl font-bold mb-4">Technologies We Work With</h2>
</div>
<!-- Portfolio Filter >
<div class="flex flex-wrap justify-center mb-12 fade-in">
<div class="bg-white rounded-full shadow-sm p-1 inline-flex" id="portfolio-filters">
<button id="filter-all" class="px-6 py-2 rounded-full bg-primary text-white whitespace-nowrap">All Technologies</button>
<button id="filter-ai" class="px-6 py-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors whitespace-nowrap">AI</button>
<button id="filter-web" class="px-6 py-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors whitespace-nowrap">Web</button>
<button id="filter-uiux" class="px-6 py-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors whitespace-nowrap">UI/UX</button>
<button id="filter-js" class="px-6 py-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors whitespace-nowrap">JS</button>
<button id="filter-marketing" class="px-6 py-2 rounded-full text-gray-700 hover:bg-gray-100 transition-colors whitespace-nowrap">Marketing</button>
</div>
</div>
<!-- Portfolio Grid >
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-8 fade-in" id="portfolio-grid">
<!-- Project 1 >
<div  data-category="ai" style="transition: opacity 0.3s ease, transform 0.3s ease; text-align: center;">
<img src="images/ai-tool-redescreation.webp"  id="tech" style="max-width: 100%; height: auto; display: inline-block;">
</div>

<!-- Project 2 >
<div data-category="web" style="transition: opacity 0.3s ease, transform 0.3s ease; text-align: center;">
  <img src="images/RC_Revamp-Website-Icons-Web-1.webp" id="tech" style="max-width: 100%; height: auto; display: inline-block;">
</div>

<!-- Project 3 >
<div data-category="uiux" style="transition: opacity 0.3s ease, transform 0.3s ease; text-align: center;">
<img src="images/RC_Revamp-Website-Icons-JS.webp" id="tech" style="max-width: 100%; height: auto; display: inline-block;">
</div>
<!-- Project 4 >
<div data-category="js" style="transition: opacity 0.3s ease, transform 0.3s ease; text-align: center;">
<img src="images/RC_Revamp-Website-Icons-Marketing.webp" id="tech" style="max-width: 100%; height: auto; display: inline-block;">
</div>
<!-- Project 5 >
<div data-category="marketing" style="transition: opacity 0.3s ease, transform 0.3s ease; text-align: center;">
<img src="images/RC_Revamp-Website-Icons-UI-UX.webp" id="tech" style="max-width: 100%; height: auto; display: inline-block;">
</div>
</div>
</div>
</section-->
	
	
	

<!-- About Section >
<section id="about" class="py-20">
<div class="container mx-auto px-4">
<div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
<div class="fade-in">
<img src="images/about-rc.jpg" alt="About Redes Creation" class="rounded-lg shadow-lg w-full h-auto">
</div>
<div class="fade-in">
<h2 class="text-3xl md:text-4xl font-bold mb-6">About Redes Creation</h2>
<p class="text-gray-600 mb-6">
Founded in 2021, Redes Creation has Established itself as a leading Web Development Company and Digital Agency. We combine Creativity, Technology, and Strategic Thinking to Deliver exceptional Digital Solutions that help Businesses thrive in the competitive online landscape.
</p>
<p class="text-gray-600 mb-8">
Our team of skilled Developers, Designers, and Digital Marketers work collaboratively to create tailored solutions that align with our Client's Business objectives. We pride ourselves on our Commitment to Quality, Innovation, and Client Satisfaction.
</p>
<div class="grid grid-cols-2 gap-6 mb-8">
<div>
<div class="flex items-center mb-2">
<div class="w-8 h-8 flex items-center justify-center mr-3">
<i class="ri-check-line text-primary text-xl"></i>
</div>
<span class="font-medium">Expert Team</span>
</div>
<div class="flex items-center mb-2">
<div class="w-8 h-8 flex items-center justify-center mr-3">
<i class="ri-check-line text-primary text-xl"></i>
</div>
<span class="font-medium">Timely Delivery</span>
</div>
<div class="flex items-center">
<div class="w-8 h-8 flex items-center justify-center mr-3">
<i class="ri-check-line text-primary text-xl"></i>
</div>
<span class="font-medium">Custom Solutions</span>
</div>
</div>
<div>
<div class="flex items-center mb-2">
<div class="w-8 h-8 flex items-center justify-center mr-3">
<i class="ri-check-line text-primary text-xl"></i>
</div>
<span class="font-medium">Affordable Pricing</span>
</div>
<div class="flex items-center mb-2">
<div class="w-8 h-8 flex items-center justify-center mr-3">
<i class="ri-check-line text-primary text-xl"></i>
</div>
<span class="font-medium">24/7 Support</span>
</div>
<div class="flex items-center">
<div class="w-8 h-8 flex items-center justify-center mr-3">
<i class="ri-check-line text-primary text-xl"></i>
</div>
<span class="font-medium">Client-Centric Approach</span>
</div>
</div>
</div>
<a href="#contact" class="bg-primary text-white px-8 py-3 !rounded-button hover:bg-primary/90 transition-colors inline-block whitespace-nowrap">Get to Know Us</a>
</div>
</div>
</div>
</section-->
	
	

<!-- Service Details Accordion >
<section class="py-20 bg-gray-50">
<div class="container mx-auto px-4">
<div class="text-center mb-16 fade-in">
<h2 class="text-3xl md:text-4xl font-bold mb-4">Our Service Details</h2>
<p class="text-gray-600 max-w-2xl mx-auto">Explore our comprehensive range of services designed to elevate your digital presence.</p>
</div>
<div class="max-w-3xl mx-auto fade-in">
<div class="space-y-4">
<!-- Accordion Item 1 >
<div class="bg-white rounded-lg border border-gray-200">
<button class="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none accordion-button">
<span class="text-lg font-semibold">Web Development Solutions</span>
<i class="ri-arrow-down-s-line text-2xl text-primary transition-transform"></i>
</button>
<div class="px-6 py-4 border-t border-gray-100 hidden accordion-content">
<ul class="space-y-3 text-gray-600">
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Custom Website Development</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>E-commerce Solutions</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Web Application Development</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>CMS Development</span>
</li>
</ul>
</div>
</div>
<!-- Accordion Item 2 >
<div class="bg-white rounded-lg border border-gray-200">
<button class="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none accordion-button">
<span class="text-lg font-semibold">Digital Marketing Services</span>
<i class="ri-arrow-down-s-line text-2xl text-primary transition-transform"></i>
</button>
<div class="px-6 py-4 border-t border-gray-100 hidden accordion-content">
<ul class="space-y-3 text-gray-600">
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Search Engine Optimization (SEO)</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Social Media Marketing</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Pay-Per-Click Advertising</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Content Marketing</span>
</li>
</ul>
</div>
</div>
<!-- Accordion Item 3 >
<div class="bg-white rounded-lg border border-gray-200">
<button class="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none accordion-button">
<span class="text-lg font-semibold">UI/UX Design</span>
<i class="ri-arrow-down-s-line text-2xl text-primary transition-transform"></i>
</button>
<div class="px-6 py-4 border-t border-gray-100 hidden accordion-content">
<ul class="space-y-3 text-gray-600">
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>User Interface Design</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>User Experience Design</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Responsive Design</span>
</li>
<li class="flex items-center">
<i class="ri-check-line text-primary mr-3"></i>
<span>Prototyping & Wireframing</span>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</section-->



<!-- FAQ Section >
<section class="py-20">
<div class="container mx-auto px-4">
<div class="text-center mb-16 fade-in">
<h2 class="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
<p class="text-gray-600 max-w-2xl mx-auto">Find answers to common questions about our services and processes.</p>
</div>
<div class="max-w-3xl mx-auto fade-in">
<div class="space-y-4">
<!-- FAQ Item 1 >
<div class="bg-white rounded-lg border border-gray-200">
<button class="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none accordion-button">
<span class="text-lg font-semibold">How long does it take to complete a website project?</span>
<i class="ri-arrow-down-s-line text-2xl text-primary transition-transform"></i>
</button>
<div class="px-6 py-4 border-t border-gray-100 hidden accordion-content">
<p class="text-gray-600">The timeline varies depending on the project scope and complexity. A basic website typically takes 4-6 weeks, while more complex projects may take 8-12 weeks or more. We'll provide a detailed timeline during our initial consultation.</p>
</div>
</div>
<!-- FAQ Item 2 >
<div class="bg-white rounded-lg border border-gray-200">
<button class="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none accordion-button">
<span class="text-lg font-semibold">What is your pricing structure?</span>
<i class="ri-arrow-down-s-line text-2xl text-primary transition-transform"></i>
</button>
<div class="px-6 py-4 border-t border-gray-100 hidden accordion-content">
<p class="text-gray-600">Our pricing is project-based and depends on your specific requirements. We offer competitive rates and flexible packages to suit different budgets. Contact us for a detailed quote tailored to your needs.</p>
</div>
</div>
<!-- FAQ Item 3 >
<div class="bg-white rounded-lg border border-gray-200">
<button class="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none accordion-button">
<span class="text-lg font-semibold">Do you provide ongoing support and maintenance?</span>
<i class="ri-arrow-down-s-line text-2xl text-primary transition-transform"></i>
</button>
<div class="px-6 py-4 border-t border-gray-100 hidden accordion-content">
<p class="text-gray-600">Yes, we offer comprehensive maintenance packages and ongoing support to ensure your website remains secure, up-to-date, and performs optimally. Our team is always available to address any issues or make updates as needed.</p>
</div>
</div>
<!-- FAQ Item 4 >
<div class="bg-white rounded-lg border border-gray-200">
<button class="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none accordion-button">
<span class="text-lg font-semibold">What technologies do you use?</span>
<i class="ri-arrow-down-s-line text-2xl text-primary transition-transform"></i>
</button>
<div class="px-6 py-4 border-t border-gray-100 hidden accordion-content">
<p class="text-gray-600">We use the latest technologies and frameworks to ensure optimal performance and security. Our tech stack includes HTML5, CSS3, JavaScript, PHP, React, Node.js, and various other modern development tools based on project requirements.</p>
</div>
</div>
</div>
</div>
</div>
</section-->

<section style="overflow:hidden; background:#0042AA; color:#fff; min-height:100vh; width:100%; padding:60px 0;">
  <style>
    .faq-container {
      max-width:1280px;
      margin:0 auto;
      display:flex;
      flex-wrap:wrap;
      align-items:flex-start;
      gap: 60px;
      padding: 0 18px;
    }
    .faq-left {
      flex:1 1 280px;
      min-width:270px;
    }
    .faq-title {
      font-size:2.2rem;
      font-weight:600;
      line-height:1.09;
      margin-top:30px;
      margin-bottom:18px;
    }
    .faq-right {
      flex:2 1 500px;
      min-width:330px;
    }
    .faq-list {
      width:100%;
    }
    .faq-item {
      border-bottom: 1px solid #285fb0;
      padding: 22px 0 22px 0;
    }
    .faq-question {
      display:flex;
      justify-content:space-between;
      align-items:center;
      cursor:pointer;
      font-size:1.03rem;
      font-weight:600;
      outline:none;
    }
    .faq-plus {
      width:32px;
      height:32px;
      background:#604eb2;
      border-radius:50%;
      color:#fff;
      display:flex;
      justify-content:center;
      align-items:center;
      font-size:1.5rem;
      font-weight:700;
      transition:background .2s;
      user-select:none;
      margin-left:14px;
    }
    .faq-question.open .faq-plus, .faq-plus.faq-minus {
      background: #fff;
      color: #604eb2;
      transition:background .2s, color .2s;
    }
    .faq-answer {
      font-size:.99rem;
      padding:10px 4px 0 0;
      color:#fffb;
      display:none;
      line-height:1.75;
      font-weight: 400;
    }
    .faq-answer.open {
      display:block;
      animation:faqAnim .4s;
    }
    @keyframes faqAnim {from{opacity:0;transform:translateY(-8px);}to{opacity:1;transform:translateY(0);}}
    .faq-yellow-dot {
      display:inline-block;width:8px;height:8px;background:#ffb800;border-radius:50%;margin-bottom:2px;margin-right:7px;
    }
    .faq-meta {
      font-size:14px;
      letter-spacing: 1px;
      font-weight:bold;
      opacity:0.7;
      margin-bottom:9px;
    }
    @media (max-width:780px) {
      .faq-container {flex-direction:column;gap:38px;}
      .faq-left,.faq-right {min-width:0;}
      .faq-title {margin-top:0;}
    }
  </style>
  <div class="faq-container">
    <div class="faq-left">
      <span class="faq-meta">
        <span class="faq-yellow-dot"></span>FAQs
      </span>
      <div class="faq-title">
        Have questions?<br>Get them answered
      </div>
    </div>
    <div class="faq-right">
      <div class="faq-list">
        <div class="faq-item">
          <div class="faq-question" tabindex="0">
            What type of industries do you serve?
            <span class="faq-plus">+</span>
          </div>
          <div class="faq-answer">
            We work across regulated and high-growth industries, including:<br>
            University &amp; Colleges<br>
            Healthcare &amp; MedTech<br>
            Finance &amp; Insurance<br>
            Retail &amp; eCommerce<br>
            Manufacturing &amp; Supply Chain<br>
            Media &amp; Entertainment<br><br>
            Cannot find your industry listed here? <a href="#" style="color:#FFB800;text-decoration:underline;">Contact us</a> to know how we can help you.
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" tabindex="0">
            Do you handle end-to-end design, or only the interface layer?
            <span class="faq-plus">+</span>
          </div>
          <div class="faq-answer">
            We provide both: full end-to-end design or focused interface design as required by your project.
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" tabindex="0">
            How secure is the data shared during projects?
            <span class="faq-plus">+</span>
          </div>
          <div class="faq-answer">
            All data is managed and transmitted under strict security practices, with NDAs and compliance as per your industry standards.
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" tabindex="0">
            What makes your digital transformation approach future-proof and scalable?
            <span class="faq-plus">+</span>
          </div>
          <div class="faq-answer">
            Our solutions are built to scale with modular components and modern, extensible tech stacks.
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" tabindex="0">
            Can you integrate digital solutions with our existing ERP/CRM?
            <span class="faq-plus">+</span>
          </div>
          <div class="faq-answer">
            Yes, integration with your ERP/CRM is a core strength, with robust and seamless data flows.
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" tabindex="0">
            What makes Galaxy Weblinks the best digital transformation and software development company?
            <span class="faq-plus">+</span>
          </div>
          <div class="faq-answer">
            Our experience, technical expertise, and innovation help us deliver results that exceed expectations.
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question" tabindex="0">
            Can you help us integrate AI solutions into our existing legacy software?
            <span class="faq-plus">+</span>
          </div>
          <div class="faq-answer">
            Absolutely, we architect smooth AI integrations into diverse and even legacy environments.
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    document.querySelectorAll('.faq-question').forEach((q, idx) => {
      q.addEventListener('click', function() {
        const ans = q.nextElementSibling;
        const icon = q.querySelector('.faq-plus');
        const isOpen = ans.classList.contains('open');
        document.querySelectorAll('.faq-answer').forEach(a => a.classList.remove('open'));
        document.querySelectorAll('.faq-plus').forEach(i => {i.textContent = '+'; i.classList.remove('faq-minus');});
        document.querySelectorAll('.faq-question').forEach(qu => qu.classList.remove('open'));
        if (!isOpen) {
          ans.classList.add('open');
          icon.textContent = '–';
          icon.classList.add('faq-minus');
          q.classList.add('open');
        }
      });
      q.addEventListener('keydown', function(e) {
        if (e.key === "Enter" || e.key === " ") q.click();
      });
    });
  </script>
</section>

<!-- Testimonials Section -->
<section class="py-20">
<div class="max-w-7xl container mx-auto px-4">
<div class="text-center mb-16 fade-in">
<h2 class="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
<p class="text-gray-600 max-w-2xl mx-auto">Don't just take our word for it. Here's what our clients have to say about working with us.</p>
</div>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 fade-in">
<!-- Testimonial 1 -->
<div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
<div class="flex mb-6">
<div class="text-primary">
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
</div>
</div>
<p class="text-gray-600 mb-6 italic">"Redes Creation transformed our outdated website into a modern, user-friendly platform that perfectly represents our brand. Their team was professional, responsive, and delivered beyond our expectations."</p>
<div class="flex items-center">
<div class="w-12 h-12 rounded-full overflow-hidden mr-4">
<img src="images/1.jpg" alt="Sarah Johnson" class="w-full h-full object-cover">
</div>
<div>
<h4 class="font-semibold">Himali Shukla</h4>
<p class="text-gray-500 text-sm">Marketing Director, Elevate Fashion</p>
</div>
</div>
</div>
<!-- Testimonial 2 -->
<div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
<div class="flex mb-6">
<div class="text-primary">
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
</div>
</div>
<p class="text-gray-600 mb-6 italic">"The digital marketing campaign developed by Redes Creation helped us increase our online visibility significantly. Our organic traffic has grown by 200% and conversions are up by 85%. Highly recommended!"</p>
<div class="flex items-center">
<div class="w-12 h-12 rounded-full overflow-hidden mr-4">
<img src="images/2.jpg" alt="Michael Reynolds" class="w-full h-full object-cover">
</div>
<div>
<h4 class="font-semibold">Rahul Vyas</h4>
<p class="text-gray-500 text-sm">CEO, InfoSphere Solutions</p>
</div>
</div>
</div>
<!-- Testimonial 3 -->
<div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow border border-gray-100">
<div class="flex mb-6">
<div class="text-primary">
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
<i class="ri-star-fill"></i>
</div>
</div>
<p class="text-gray-600 mb-6 italic">"Working with Redes Creation on our e-commerce platform was a game-changer for our business. The site is not only beautiful but also highly functional, resulting in a 40% increase in online sales within the first month."</p>
<div class="flex items-center">
<div class="w-12 h-12 rounded-full overflow-hidden mr-4">
<img src="images/3.jpg" alt="Jennifer Martinez" class="w-full h-full object-cover">
</div>
<div>
<h4 class="font-semibold">Priya Gupta</h4>
<p class="text-gray-500 text-sm">Owner, Artisan Crafts Co.</p>
</div>
</div>
</div>
</div>
</div>
</section>

<section style="position:relative;width:100%;min-height:530px;background:#0042AA;overflow:hidden;">
  <style>
    .leadership-hero {
      display:flex;
      flex-wrap:wrap;
      align-items:center;
      justify-content:space-between;
      max-width:1480px;
      margin:0 auto;
      min-height:530px;
      position:relative;
      z-index:2;
      gap:16px;
      padding:56px 6vw 32px 6vw;
    }
    .leadership-left {
      flex:1 1 520px;
      min-width:320px;
      z-index:2;
    }
    .leadership-quote {
      font-size:3rem;
      line-height:1.04;
      font-weight:bold;
      color:#fff;
      margin-bottom:24px;
      letter-spacing: -1px;
    }
    .leadership-message {
      font-size:1.18rem;
      color:#fff;
      font-weight:500;
      line-height:1.57;
      margin-bottom:36px;
      max-width:680px;
    }
    .leadership-name {
      font-size:2rem;
      font-weight:700;
      color:#fff;
      margin-bottom:2px;
    }
    .leadership-ceo {
      font-size:1.04rem;
      color:#fff;
      font-weight:400;
      margin-bottom:28px;
    }
    .leadership-xline {
      display:flex;
      align-items:center;
      gap:22px;
      margin-top:22px;
      margin-bottom:18px;
    }
    .leadership-xline span {
      font-size:2.5rem;
      color:#fff;
      font-weight:bold;
      letter-spacing:16px;
    }
    .leadership-xline .x-divider {
      height:2px;
      background:rgba(255,255,255,0.6);
      flex:1 1 70px;
      border:none;
    }
    .leadership-right {
      flex:2 1 490px;
      position:relative;
      min-width:320px;
      display:flex;
      align-items:center;
      justify-content:flex-end;
      padding-right:5vw;
      height:100%;
    }
    .ceo-img-container {
      position:relative;
      width:440px;
      height:450px;
      display:flex;
      align-items:center;
      justify-content:center;
    }
    .ceo-img {
      width:100%;
      height:100%;
      object-fit:cover;
      filter:contrast(0.97) brightness(0.93) grayscale(7%) sepia(12%);
      border-radius:22px;
    }
    .hero-diagonal-bg {
      position:absolute;
      top:0;left:0;right:0;bottom:0;
      z-index:0;
      pointer-events:none;
      background-repeat:no-repeat;
      background-size:cover;
      opacity:1;
      background-image:
        linear-gradient(120deg, rgba(235,89,48,0.11) 24%, transparent 25%), 
        linear-gradient(-120deg, rgba(235,89,48,0.13) 24%, transparent 25%);
    }

    .diagonal-bar {
      position:absolute;
      right:3vw;
      top:18%;
      width:35px;
      height:320px;
      background: repeating-linear-gradient(
        -65deg,
        #fff 0 7px,
        transparent 7px 17px
      );
      z-index:4;
      border-radius:5px;
      opacity:0.86;
      pointer-events:none;
    }
    @media(max-width:950px){
      .leadership-hero{flex-direction:column-reverse;align-items:flex-start;padding:44px 2vw;}
      .leadership-right{width:100%;justify-content:center;padding-right:0;}
      .ceo-img-container{width:95vw;height:350px;max-width:420px;}
      .diagonal-bar{height:170px;top:auto;bottom:30px;}
      .leadership-left{padding-right:0;}
      .leadership-quote{font-size:2.09rem;}
      .leadership-message{font-size:1.05rem;}
    }
    @media(max-width:640px){
      .leadership-hero{padding:28px 0;}
      .leadership-quote{font-size:1.19rem;}
      .leadership-message{font-size:0.95rem;}
      .leadership-name, .leadership-ceo{font-size:1rem;}
      .leadership-xline span{font-size:1.3rem;}
      .ceo-img-container{height:150px;}
      .diagonal-bar{height:70px;right:7vw;}
    }
  </style>
  <div class="hero-diagonal-bg"></div>
  <div class="leadership-hero">
    <div class="leadership-left">
      <div class="leadership-quote">Build. Innovate. Elevate.</div>
      <div class="leadership-message">
        We are a team of creators and strategists who combine cutting-edge technology with design thinking to build powerful digital experiences. From websites to AI-driven solutions — we craft what connects, converts, and inspires.
      </div>
      <div class="leadership-name">Bhavana M Rajpurohit</div>
      <div class="leadership-ceo">CEO</div>
      <div class="leadership-xline">
        <span>&#10006;</span><span>&#10006;</span>
        <hr class="x-divider"><span>&#10006;</span>
      </div>
    </div>
    <div class="leadership-right">
      <div class="ceo-img-container">
        <img src="assets/ceo-bhav.jpg" alt="CEO" class="ceo-img">
      </div>
    </div>
    <div class="diagonal-bar"></div>
  </div>
</section>

<section class="bg-white min-h-screen w-full py-16 text-gray-800">
  <div class="max-w-7xl mx-auto px-6">
    <!-- Trusted Companies -->
    <h2 class="text-3xl font-semibold mb-5">
      Trusted by <span class="text-[#11C0FF] font-bold">100+</span> companies
    </h2>
    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-10 items-center mb-14">
      <img src="/assets/brands/brahmos-logo.png" alt="Brahmos Logistics" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/bhav-logo.png" alt="BhavLife" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/mu-logo.png" alt="Madhav University" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/abunet-logo.png" alt="AbuNetConnect Pvt. Ltd." class="h-16 w-auto mx-auto">
      <img src="/assets/brands/st-pauls-logo.png" alt="St. Paul's Sr. Sc. School" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/somalal-logo.png" alt="Soni Somalal & Sons" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/onelife-logo.png" alt="OneLife Natural" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/affirmations-logo.png" alt="Affirmations" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/secrox-logo.png" alt="Secrox Gaming" class="h-16 w-auto mx-auto">
      <img src="/assets/brands/saini-logo.png" alt="Saini Digital" class="h-16 w-auto mx-auto">
    </div>

    <!-- Our Expertise -->
    <h2 class="text-2xl font-semibold mb-8">
      Our <span class="text-[#11C0FF] font-bold">Expertise</span>
    </h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-7">
      <!-- Card 1 -->
      <div class="rounded-xl bg-gradient-to-tr from-pink-100 to-white p-6 shadow hover:shadow-lg transition flex flex-col min-h-[220px]">
        <div class="mb-2">
          <img src="https://creativelogodesign.us/assets/images/ecommerce_logo_maker.png" alt="PHP" class="h-9 w-auto">
        </div>
        <h3 class="font-semibold text-lg mb-1">Ecommerce Development</h3>
        <p class="text-gray-700 text-sm flex-grow">Transform your online presence with enterprise ecommerce solutions powered by AI. Custom…</p>
        <span class="self-end mt-3 text-xl text-gray-600">&#x2192;</span>
      </div>
      <!-- Card 2 -->
      <div class="rounded-xl bg-gradient-to-tr from-blue-100 to-white p-6 shadow hover:shadow-lg transition flex flex-col min-h-[220px]">
        <div class="mb-2">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/PHP-logo.svg/2560px-PHP-logo.svg.png" alt="PHP" class="h-9 w-auto">
        </div>
        <h3 class="font-semibold text-lg mb-1">PHP Development</h3>
        <p class="text-gray-700 text-sm flex-grow">We specialize in delivering custom PHP development services, from simple app development to enterprise PHP solutions.</p>
        <span class="self-end mt-3 text-xl text-gray-600">&#x2192;</span>
      </div>
      <!-- Card 3 -->
      <div class="rounded-xl bg-gradient-to-tr from-orange-100 to-white p-6 shadow hover:shadow-lg transition flex flex-col min-h-[220px]">
        <div class="mb-2">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Logo.min.svg/2560px-Logo.min.svg.png" alt="Laravel" class="h-9 w-auto">
        </div>
        <h3 class="font-semibold text-lg mb-1">Laravel Development</h3>
        <p class="text-gray-700 text-sm flex-grow">Looking for smarter ways to manage and utilize your business data? As a leading Laravel…</p>
        <span class="self-end mt-3 text-xl text-gray-600">&#x2192;</span>
      </div>
      <!-- Card 4 -->
      <div class="rounded-xl bg-gradient-to-tr from-blue-100 to-white p-6 shadow hover:shadow-lg transition flex flex-col min-h-[220px]">
        <div class="mb-2">
          <img src="https://upload.wikimedia.org/wikipedia/commons/2/20/WordPress_logo.svg" alt="WordPress" class="h-9 w-auto">
        </div>
        <h3 class="font-semibold text-lg mb-1">WordPress</h3>
        <p class="text-gray-700 text-sm flex-grow">Elsner is a top-rated WordPress development company with 18+ years of experience delivering…</p>
        <span class="self-end mt-3 text-xl text-gray-600">&#x2192;</span>
      </div>
      <!-- Card 5 -->
      <div class="rounded-xl bg-gradient-to-tr from-orange-100 to-white p-6 shadow hover:shadow-lg transition flex flex-col min-h-[220px]">
        <div class="mb-2">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Shopify_logo_2018.svg/1280px-Shopify_logo_2018.svg.png" alt="Shopify" class="h-9 w-auto">
        </div>
        <h3 class="font-semibold text-lg mb-1">Shopify</h3>
        <p class="text-gray-700 text-sm flex-grow">We offer AI-enhanced Shopify Development Services that solve real-time issues such as slow site…</p>
        <span class="self-end mt-3 text-xl text-gray-600">&#x2192;</span>
      </div>
    </div>
  </div>
</section>

<section class="bg-[#0042AA] w-full py-12">
  <div class="max-w-7xl mx-auto flex items-center justify-between gap-8 px-7">
    <!-- Headline -->
    <div>
      <h2 class="text-4xl md:text-5xl font-bold text-white mb-0 leading-tight">
        Your Growth Journey Deserves a <br>
        Strategic Tech Partner
      </h2>
    </div>
    <!-- CTA Button -->
    <div class="flex items-center gap-8">
      <a href="#contact" class="inline-block bg-[#FFB800] px-8 py-4 rounded-full text-lg font-semibold shadow hover:bg-yellow-500 transition text-[#232323]">
        Schedule A Discovery Call
      </a>
      <span class="text-white text-3xl">&#8592;</span>
    </div>
  </div>
</section>


    <!-- CTA Section >
    <section class="py-20 bg-primary">
      <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl md:text-4xl font-bold text-white mb-6">
          Ready to Transform Your Digital Presence?
        </h2>
        <p class="text-white opacity-90 max-w-2xl mx-auto mb-8">
          Let's collaborate to create exceptional digital experiences that drive
          business growth and engage your audience.
        </p>
        <div class="flex flex-col sm:flex-row justify-center gap-4">
          <a
            href="#quote"
            id="quote"
            class="bg-white text-primary px-8 py-3 font-medium !rounded-button whitespace-nowrap"
          >
            Request a Quote
          </a>
          <a
            href="#contact"
            class="border-2 border-white text-white px-8 py-3 font-medium !rounded-button whitespace-nowrap"
          >
            Contact Us
          </a>
        </div>
      </div>
    </section-->
    
    

    <!-- Contact Section -->
<section id="contact" class="py-20">
<div class="max-w-7xl container mx-auto px-4">
<div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
<div class="fade-in">
<h2 class="text-3xl md:text-4xl font-bold mb-6">Get in Touch</h2>
<p class="text-gray-600 mb-8">
Have a project in mind or want to learn more about our services? Fill out the form below, and our team will get back to you as soon as possible.
</p>
<form>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
<div>
<label for="name" class="block text-gray-700 mb-2">Full Name</label>
<input type="text" id="name" class="w-full px-4 py-3 rounded border border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary text-sm" placeholder="Chirag Malviya">
</div>
<div>
<label for="email" class="block text-gray-700 mb-2">Email Address</label>
<input type="email" id="email" class="w-full px-4 py-3 rounded border border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary text-sm" placeholder="redescreation@gmail.com">
</div>
</div>
<div class="mb-6">
<label for="phone" class="block text-gray-700 mb-2">Phone Number</label>
<input type="tel" id="phone" class="w-full px-4 py-3 rounded border border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary text-sm" placeholder="+919676659153">
</div>
<div class="mb-6">
<label for="service" class="block text-gray-700 mb-2">Service Interested In</label>
<div class="relative">
<select id="service" class="w-full px-4 py-3 rounded border border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary appearance-none bg-white text-sm pr-8">
<option value="" selected disabled>Select a service</option>
<option value="web-development">Web Development</option>
<option value="digital-marketing">Digital Marketing</option>
<option value="industry-tech">Industry Tech Solutions</option>
<option value="graphic-design">Graphic Design</option>
</select>
<div class="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
<i class="ri-arrow-down-s-line text-gray-500"></i>
</div>
</div>
</div>
<div class="mb-6">
<label for="message" class="block text-gray-700 mb-2">Your Message</label>
<textarea id="message" rows="5" class="w-full px-4 py-3 rounded border border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary text-sm" placeholder="Tell us about your project..."></textarea>
</div>
<div class="mb-6">
<label class="flex items-center">
<div class="relative inline-block w-5 h-5 mr-3">
<input type="checkbox" class="absolute opacity-0 w-0 h-0">
<span class="w-5 h-5 border border-gray-300 rounded inline-block relative">
<span class="absolute inset-0 bg-primary scale-0 rounded-sm transition-transform duration-200 flex items-center justify-center transform origin-center"></span>
</span>
</div>
<span class="text-gray-600 text-sm">I agree to the <a href="#" class="text-primary hover:underline">Privacy Policy</a> and <a href="#" class="text-primary hover:underline">Terms of Service</a>.</span>
</label>
</div>
<button type="submit" class="bg-primary text-white px-8 py-3 !rounded-button hover:bg-primary/90 transition-colors whitespace-nowrap">Send Message</button>
</form>
</div>
<div class="fade-in">
<div class="bg-gray-50 rounded-lg p-8 h-full">
<h3 class="text-2xl font-semibold mb-6">Contact Information</h3>
<div class="space-y-6">
<div class="flex items-start">
<div class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full mr-4 mt-1">
<i class="ri-map-pin-line text-primary"></i>
</div>
<div>
<h4 class="font-medium mb-1">Office Address</h4>
<p class="text-gray-600">2nd Floor, Maruti Complex, <br>Abu Road, Rajasthan 307026, India</p>
</div>
</div>
<div class="flex items-start">
<div class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full mr-4 mt-1">
<i class="ri-phone-line text-primary"></i>
</div>
<div>
<h4 class="font-medium mb-1">Phone Number</h4>
<p class="text-gray-600">+91 96766-59153</p>
<p class="text-gray-600">+91 90570-71463</p>
</div>
</div>
<div class="flex items-start">
<div class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full mr-4 mt-1">
<i class="ri-mail-line text-primary"></i>
</div>
<div>
<h4 class="font-medium mb-1">Email Address</h4>
<p class="text-gray-600">info@redescreation.in</p>
<p class="text-gray-600">redescreation@gmail.com</p>
</div>
</div>
<div class="flex items-start">
<div class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full mr-4 mt-1">
<i class="ri-time-line text-primary"></i>
</div>
<div>
<h4 class="font-medium mb-1">Business Hours</h4>
<p class="text-gray-600">Monday - Friday: 9:00 AM - 6:00 PM</p>
<p class="text-gray-600">Saturday: 10:00 AM - 2:00 PM</p>
<p class="text-gray-600">Sunday: Closed</p>
</div>
</div>
</div>
<div class="mt-8">
<h4 class="font-medium mb-4">Connect With Us</h4>
<div class="flex space-x-4">
<a href="https://www.instagram.com/redescreation" class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full hover:bg-primary/20 transition-colors">
<i class="ri-instagram-fill text-primary"></i>
</a>
<a href="#" class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full hover:bg-primary/20 transition-colors">
<i class="ri-facebook-fill text-primary"></i>
</a>
<a href="#" class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full hover:bg-primary/20 transition-colors">
<i class="ri-twitter-fill text-primary"></i>
</a>
<a href="#" class="w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full hover:bg-primary/20 transition-colors">
<i class="ri-linkedin-fill text-primary"></i>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

    <!-- Footer -->
<footer class="footer-bg text-white pt-16 pb-8">
  <div class="max-w-7xl container mx-auto px-4">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
      
      <!-- Our Services -->
      <div>
        <h4 class="text-xl font-semibold mb-6">Our Services</h4>
        <ul class="space-y-3">
          <li><a href="#" class="text-gray-300 hover:text-white transition">Web Development</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Digital Marketing</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">UI/UX Design</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">E-commerce Solutions</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Mobile App Development</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Branding & Identity</a></li>
        </ul>
      </div>

      <!-- Quick Links -->
      <!-- Quick Links -->
<div>
  <h4 class="text-xl font-semibold mb-6">Quick Links</h4>
  <ul class="space-y-3">
    <li>
      <a href="index.php" class="text-gray-300 hover:text-white transition">
        Home
      </a>
    </li>
    <li>
      <a href="services.php" class="text-gray-300 hover:text-white transition">
        Services
      </a>
    </li>
    <li>
      <a href="portfolio.php" class="text-gray-300 hover:text-white transition">
        Portfolio
      </a>
    </li>
    <li>
      <a href="about.php" class="text-gray-300 hover:text-white transition">
        About Us
      </a>
    </li>
    <li>
      <a href="contact.php" class="text-gray-300 hover:text-white transition">
        Contact
      </a>
    </li>
    <li>
      <a href="quote.php" class="text-gray-300 hover:text-white transition">
        Request a Quote
      </a>
    </li>
  </ul>
</div>

      <!-- Other Websites -->
      <div>
        <h4 class="text-xl font-semibold mb-6">Other Websites</h4>
        <ul class="space-y-3">
          <li><a href="#" class="text-gray-300 hover:text-white transition">Bhaagya</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Prabh</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Geet</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">E-commerce Solutions</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Paay</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Destiny Solutions</a></li>
        </ul>
      </div>

      <!-- ✅ Mailchimp Newsletter -->
      <div>
        <h4 class="text-xl font-semibold mb-6">Newsletter</h4>
        <p class="text-gray-300 mb-4">
          Subscribe to our newsletter to receive updates on our latest projects and insights.
        </p>
        <form action="https://redescreation.us12.list-manage.com/subscribe/post?u=9a2df25b21c02476bb963de58&amp;id=2ddf7a4d7d&amp;f_id=003f99e0f0"
              method="post" target="_blank" class="mb-4 flex">
          <input type="email" name="EMAIL" required
                 placeholder="Your email address"
                 class="w-full px-4 py-2 rounded-l text-gray-800 focus:outline-none" />
          <button type="submit"
                  class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-r text-white">
            <i class="ri-send-plane-fill"></i>
          </button>
        </form>
        <p class="text-gray-400 text-sm">
          By subscribing, you agree to our Privacy Policy.
        </p>
      </div>
    </div>

    <!-- Office Addresses -->
    <div class="border-t border-gray-700 pt-8">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
        <div>
          <h4 class="text-xl font-semibold mb-6">Rajasthan</h4>
          <ul class="space-y-3">
            <li class="text-gray-300">Maruti Complex,<br>Abu Road,<br>India – 307026</li>
            <li><a href="tel:+919676659153" class="text-gray-300 hover:text-white transition">+91-9676659153</a></li>
          </ul>
        </div>
        <div>
          <h4 class="text-xl font-semibold mb-6">Gujarat</h4>
          <ul class="space-y-3">
            <li class="text-gray-300">Nikol,<br>Ahmedabad,<br>India – 382350</li>
            <li><a href="tel:+919057071463" class="text-gray-300 hover:text-white transition">+91-9057071463</a></li>
          </ul>
        </div>
        <div>
          <h4 class="text-xl font-semibold mb-6">Andhra Pradesh</h4>
          <ul class="space-y-3">
            <li class="text-gray-300">Kadapa,<br>Krishnapuram,<br>India – 303001</li>
            <li><a href="tel:+919676659153" class="text-gray-300 hover:text-white transition">+91-9676659153</a></li>
          </ul>
        </div>

        <!-- Enquiry & Social Icons -->
        <div class="flex flex-col justify-start items-center gap-4">
          <!-- Buttons -->
          <div class="flex flex-col sm:flex-row gap-4">
            <a href="#" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-md shadow-md text-center w-full sm:w-auto">
              <div class="text-sm text-left">For Enquiries</div>
              <div class="text-lg font-semibold flex items-center justify-center gap-1">
                Contact <i class="ri-arrow-right-s-line"></i>
              </div>
            </a>
            <a href="#" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-md shadow-md text-center w-full sm:w-auto">
              <div class="text-sm text-left">For Career</div>
              <div class="text-lg font-semibold flex items-center justify-center gap-1">
                Apply <i class="ri-arrow-right-s-line"></i>
              </div>
            </a>
          </div>
          <!-- Social -->
          <div class="flex justify-center gap-3 mt-4">
            <a href="https://www.instagram.com/redescreation" class="text-pink-500 text-2xl bg-white rounded-full p-2"><i class="ri-instagram-fill"></i></a>
            <a href="#" class="text-red-600 text-2xl bg-white rounded-full p-2"><i class="ri-pinterest-fill"></i></a>
            <a href="#" class="text-sky-500 text-2xl bg-white rounded-full p-2"><i class="ri-twitter-x-fill"></i></a>
            <a href="#" class="text-red-600 text-2xl bg-white rounded-full p-2"><i class="ri-youtube-fill"></i></a>
            <a href="#" class="text-blue-700 text-2xl bg-white rounded-full p-2"><i class="ri-linkedin-fill"></i></a>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer Bottom -->
    <div class="border-t border-gray-700 pt-8">
      <div class="flex flex-col md:flex-row justify-between items-center">
        <p class="text-gray-400 mb-4 md:mb-0">
          &copy; 2025 Redes Creation. All rights reserved by <a href="https://redescreation.in/" class="text-blue-500">Redes Creation</a>
        </p>
        <div class="flex space-x-6">
          <a href="#" class="text-gray-400 hover:text-white transition">Privacy Policy</a>
          <a href="#" class="text-gray-400 hover:text-white transition">Terms of Service</a>
          <a href="#" class="text-gray-400 hover:text-white transition">Cookie Policy</a>
        </div>
      </div>
    </div>
  </div>


<!--?php include("features/combined-notification.php"); ?-->
<style>
    
.floating-whatsapp {
  position: fixed;
  bottom: 20px;
  left: 20px;
  width: 56px;
  height: 56px;
  background-color: #25D366;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;
  z-index: 9999;
  text-decoration: none;
}

.floating-whatsapp:hover {
  transform: scale(1.1);
}
    </style>
    
    
    
<a href="https://wa.me/919676659153?text=I'm%20interested%20in%20your%20services" class="floating-whatsapp" target="_blank" aria-label="Chat on WhatsApp">
  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 32 32" fill="white">
    <path d="M16.004 2.002c-7.731 0-14.004 6.271-14.004 14.002 0 2.472 0.647 4.875 1.872 7.007l-1.975 7.23 7.396-1.942c1.997 1.09 4.276 1.667 6.711 1.667 7.731 0 14.004-6.271 14.004-14.002s-6.273-14.002-14.004-14.002zM16.004 26.771c-2.076 0-4.076-0.544-5.832-1.574l-0.418-0.246-4.393 1.153 1.173-4.278-0.272-0.438c-1.158-1.859-1.769-4.005-1.769-6.171 0-6.457 5.252-11.709 11.709-11.709s11.709 5.252 11.709 11.709c0 6.456-5.252 11.708-11.709 11.708zM22.142 19.491c-0.344-0.172-2.041-1.007-2.359-1.121-0.319-0.118-0.553-0.172-0.787 0.172s-0.902 1.121-1.107 1.351c-0.204 0.223-0.406 0.252-0.75 0.086-0.344-0.172-1.451-0.533-2.762-1.695-1.022-0.911-1.715-2.039-1.916-2.383-0.201-0.344-0.022-0.53 0.151-0.702 0.155-0.153 0.344-0.398 0.516-0.597 0.17-0.201 0.227-0.344 0.342-0.57 0.118-0.223 0.057-0.43-0.029-0.602-0.086-0.172-0.787-1.9-1.078-2.607-0.283-0.68-0.572-0.588-0.787-0.6-0.202-0.008-0.43-0.009-0.659-0.009s-0.602 0.086-0.916 0.43c-0.319 0.344-1.204 1.174-1.204 2.861s1.233 3.32 1.404 3.547c0.172 0.223 2.435 3.711 5.902 5.204 0.826 0.357 1.47 0.57 1.971 0.729 0.827 0.263 1.578 0.226 2.172 0.137 0.662-0.099 2.041-0.834 2.328-1.641 0.287-0.807 0.287-1.499 0.201-1.641-0.086-0.143-0.316-0.229-0.66-0.398z"/>
  </svg>
</a>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Floating Call Button</title>
  <style>
    .floating-call {
      position: fixed;
      bottom: 90px;
      right: 20px;
      width: 56px;
      height: 56px;
      background-color: #007BFF;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
      z-index: 9999;
      text-decoration: none;
    }
    .floating-call:hover {
      transform: scale(1.1);
    }
    .floating-call svg {
      width: 28px;
      height: 28px;
      fill: white;
    }
  </style>
</head>
<body>

<a href="tel:+919676659153" class="floating-call" aria-label="Call Us">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M391.2 351.3c-36.1 0-71.2-5.8-104.6-17.3-19.4-6.7-41.2-16.6-66.1-30.4-36.3-20.2-62.3-42.4-78.5-66.4-10.5-15.3-18.1-32.3-22.5-51-3.4-14.1 2.7-28.9 15.3-36.8l51.6-32c10.4-6.5 23.8-5.1 32.5 3.4l35.6 35.6c10.4 10.4 11.9 27.3 3.3 39.4l-20.6 30.2c3.5 4.7 9.6 11.5 21.4 20.7 17.4 13.7 32.7 22.2 46.2 25.5l22.3-22.3c10.4-10.4 27.3-11.9 39.4-3.3l35.6 35.6c8.5 8.5 9.9 22 3.4 32.5l-32 51.6c-5.5 8.9-15.1 14.1-25.4 14.1z"/></svg>
</a>

</body>
</html><!--?php include("features/scroll-progress.php"); ?-->
<!--?php include("features/cookie-consent.php"); ?--->
<!----?php include("features/smg-style-notification.php"); ?---->


  <!-- Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-4VBPBHNW3C"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-4VBPBHNW3C');
  </script>
</footer>    <script>
      document.addEventListener("DOMContentLoaded", function () {
        // Navbar scroll effect
        const navbar = document.getElementById("navbar");
        window.addEventListener("scroll", function () {
          if (window.scrollY > 50) {
            navbar.classList.add("nav-blur");
          } else {
            navbar.classList.remove("nav-blur");
          }
        });

        // Mobile menu toggle
        const mobileMenuButton = document.getElementById("mobile-menu-button");
        const mobileMenu = document.getElementById("mobile-menu");

        mobileMenuButton.addEventListener("click", function () {
          mobileMenu.classList.toggle("hidden");
        });
      

      document.addEventListener("DOMContentLoaded", function () {
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
          anchor.addEventListener("click", function (e) {
            e.preventDefault();

            const targetId = this.getAttribute("href");
            if (targetId === "#") return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
              window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: "smooth",
              });

              // Close mobile menu if open
              document.getElementById("mobile-menu").classList.add("hidden");
            }
          });
        });
      });
	  
			
  // Accordion functionality
  const accordionButtons = document.querySelectorAll(".accordion-button");
  accordionButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const content = this.nextElementSibling;
      const icon = this.querySelector("i");
      const isOpen = !content.classList.contains("hidden");
      // Close all accordions
      document.querySelectorAll(".accordion-content").forEach((item) => {
        item.classList.add("hidden");
      });
      document.querySelectorAll(".accordion-button i").forEach((icon) => {
        icon.style.transform = "rotate(0deg)";
      });
      // Open clicked accordion if it was closed
      if (!isOpen) {
        content.classList.remove("hidden");
        icon.style.transform = "rotate(180deg)";
      }
    });
  });
  
  
  // Custom checkbox
  const checkboxes = document.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach((checkbox) => {
    checkbox.addEventListener("change", function () {
      const span = this.nextElementSibling.querySelector("span");
      if (this.checked) {
        span.classList.add("scale-100");
        span.innerHTML = '<i class="ri-check-line text-white text-xs"></i>';
      } else {
        span.classList.remove("scale-100");
        span.innerHTML = "";
      }
    });
  });
  
  
  // Add click events to filter buttons
  document
    .getElementById("filter-all")
    .addEventListener("click", function (event) {
      filterPortfolio("all", this);
    });

  document
    .getElementById("filter-web")
    .addEventListener("click", function (event) {
      filterPortfolio("web", this);
    });
  document
    .getElementById("filter-ai")
    .addEventListener("click", function (event) {
      filterPortfolio("ai", this);
    });
  document
    .getElementById("filter-marketing")
    .addEventListener("click", function (event) {
      filterPortfolio("marketing", this);
    });
  document
    .getElementById("filter-uiux")
    .addEventListener("click", function (event) {
      filterPortfolio("uiux", this);
    });
  document
    .getElementById("filter-js")
    .addEventListener("click", function (event) {
      filterPortfolio("js", this);
    });
	
  // Portfolio Filter
  const portfolioFilters = document.getElementById("portfolio-filters");
  const portfolioGrid = document.getElementById("portfolio-grid");
  const portfolioItems = portfolioGrid.children;
  function filterPortfolio(category, button) {
    const filterButtons = portfolioFilters.children;
    // Update button states
    for (let btn of filterButtons) {
      btn.classList.remove("bg-primary", "text-white", "shadow-md");
      btn.classList.add("text-gray-700");
    }
    // Set active button with enhanced styling
    button.classList.remove("text-gray-700");
    button.classList.add("bg-primary", "text-white", "shadow-md");
    // Filter projects with enhanced animation
    Array.from(portfolioItems).forEach((item, index) => {
      const delay = index * 100;
      if (category === "all" || item.dataset.category === category) {
        item.style.display = "";
        item.style.opacity = "0";
        item.style.transform = "translateY(20px)";
        setTimeout(() => {
          item.style.opacity = "1";
          item.style.transform = "translateY(0)";
        }, delay);
      } else {
        item.style.opacity = "0";
        item.style.transform = "translateY(20px)";
        setTimeout(() => {
          item.style.display = "none";
        }, 300);
      }
    });
  }
  // Add click events to filter buttons
  document
    .getElementById("filter-all")
    .addEventListener("click", function (event) {
      filterPortfolio("all", this);
    });
  document
    .getElementById("filter-web")
    .addEventListener("click", function (event) {
      filterPortfolio("web", this);
    });
  document
    .getElementById("filter-marketing")
    .addEventListener("click", function (event) {
      filterPortfolio("marketing", this);
    });
  document
    .getElementById("filter-design")
    .addEventListener("click", function (event) {
      filterPortfolio("design", this);
    });
	
	
	});
    </script>
  </body>
</html>
