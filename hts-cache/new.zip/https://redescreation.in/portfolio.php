<!DOCTYPE html>
<html lang="en" class="overflow-x-hidden">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>REDES Creation - Web Development Company & Digital Agency</title>

    <!-- SEO Meta Tags -->
<title>Redes Creation | Web Development, Marketing & Design Agency</title>
<meta name="description" content="Redes Creation is a creative digital agency offering web development, digital marketing, branding, and graphic design services.">
<meta name="keywords" content="Redes Creation, web development, digital marketing, branding, graphic design, India">
<meta name="author" content="Redes Creation">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Open Graph Meta Tags for Social Sharing -->
<meta property="og:title" content="Redes Creation | Web Development, Marketing & Design Agency">
<meta property="og:description" content="Creative digital agency offering full-service solutions for your online business needs.">
<meta property="og:image" content="https://redescreation.in/images/cover.jpg">
<meta property="og:url" content="https://redescreation.in/">
<meta property="og:type" content="website">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Redes Creation | Web Development, Marketing & Design Agency">
<meta name="twitter:description" content="Creative digital agency offering full-service solutions for your online business needs.">
<meta name="twitter:image" content="https://redescreation.in/images/cover.jpg">
    <script src="https://cdn.tailwindcss.com/3.4.16"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: { primary: "#034bc0", secondary: "#4B4B4B" },
            borderRadius: {
              none: "0px",
              sm: "4px",
              DEFAULT: "8px",
              md: "12px",
              lg: "16px",
              xl: "20px",
              "2xl": "24px",
              "3xl": "32px",
              full: "9999px",
              button: "8px",
            },
          },
        },
      };
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.min.css"
    />
    <style>
      :where([class^="ri-"])::before { content: "\f3c2"; }
      body {
          font-family: 'Montserrat', sans-serif;
          scroll-behavior: smooth;
      }
      .nav-blur {
          backdrop-filter: blur(10px);
          background-color: rgba(255, 255, 255, 0.8);
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
          transition: all 0.3s ease;
      }
      .service-card {
          transition: all 0.3s ease;
          overflow: hidden;
          position: relative;
      }
      .service-card:hover {
          transform: translateY(-5px);
      }
      .service-card:hover .service-icon {
          transform: scale(1.1);
      }
      .service-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(135deg, rgba(192, 3, 3, 0.9), rgba(192, 3, 3, 0.7));
          opacity: 0;
          transition: all 0.3s ease;
          z-index: 1;
      }
      .service-card:hover::before {
          opacity: 1;
      }
      .service-card:hover .service-content {
          color: white;
          z-index: 2;
          position: relative;
      }
      .service-card:hover .service-title {
          color: white;
      }
      .service-icon {
          transition: all 0.3s ease;
      }
      .btn-primary {
          background: linear-gradient(135deg, #034bc0, #0140b3);
          transition: all 0.3s ease;
          box-shadow: 0 4px 15px rgb(43 138 255 / 30%);
      }
      .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(192, 3, 3, 0.4);
      }
      .btn-outline {
          transition: all 0.3s ease;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      }
      .btn-outline:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
      }
      .fade-in {
          animation: fadeIn 0.8s ease-in-out;
      }
      @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
      }
      .hero-bg {
          background: linear-gradient(135deg, rgb(3 75 192 / 90%), rgb(6 55 163 / 80%)),
                      url('assets/img/hero-bg.png');
          background-size: cover;
          background-position: center;
      }
      .footer-bg {
          background: linear-gradient(135deg, #1a1a1a, #333333);
      }
      .social-icon {
          transition: all 0.3s ease;
      }
      .social-icon:hover {
          transform: translateY(-3px);
          filter: drop-shadow(0 0 8px rgba(255, 255, 255, 0.6));
      }
      .nav-link {
          position: relative;
      }
      .nav-link::after {
          content: '';
          position: absolute;
          bottom: -4px;
          left: 0;
          width: 0;
          height: 2px;
          background-color: #034bc0;
          transition: width 0.3s ease;
      }
      .nav-link:hover::after {
          width: 100%;
      }
      .portfolio-item {
          overflow: hidden;
      }
      .portfolio-item img {
          transition: transform 0.5s ease;
      }
      .portfolio-item:hover img {
          transform: scale(1.05);
      }
      .portfolio-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: linear-gradient(to top, rgb(3 68 192 / 90%), rgb(3 61 192 / 30%));
          opacity: 0;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          justify-content: center;
      }
      .portfolio-item:hover .portfolio-overlay {
          opacity: 1;
      }
	  #navbar{
			background-color: white;
	  }
	  #flex-screen{
			min-height: 95vh;
      }
	  #tech{
			height: auto;
			max-width: 100%;
			vertical-align: middle;
	  }
	  .w-24 {
    width: 10rem;
}
#mascot {

    width: 9rem;
    --tw-translate-y: -80%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}


    </style>
    
<link rel="icon" type="image/png" href="/assets/favicon-rc-new.png" sizes="192x192">
<link rel="apple-touch-icon" href="/assets/favicon-rc-new.png">
<link rel="shortcut icon" href="/assets/favicon-rc-new.png">
<meta name="msapplication-TileImage" content="/assets/favicon-rc-new.png">
    
  </head>
  <body class="overflow-x-hidden">
    <!-- Header & Navigation -->
    <!-- HEADER START -->
<header class="header-bar">
  <nav class="nav-container">
    <!-- Logo -->
    <a href="/" class="nav-logo">
      <img src="images/redescreation-logo.png" alt="Redes Creation" class="logo-img">
      <span class="logo-text"></span>
    </a>
    <!-- Desktop Menu -->
    <ul class="nav-menu">
      <li class="nav-item dropdown">
        <a href="/" class="nav-link">Home</span></a>
        <!-- Example dropdown
        <ul class="dropdown-menu">
          <li><a href="#">Submenu 1</a></li>
          <li><a href="#">Submenu 2</a></li>
        </ul>
        -->
      </li>
      <li class="nav-item dropdown">
        <a href="about.php" class="nav-link">About</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="portfolio.php" class="nav-link">Portfolio</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="services.php" class="nav-link">Service</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="blogs" class="nav-link">Blogs</span></a>
      </li>
      <li class="nav-item dropdown">
        <a href="contact.php" class="nav-link">Contact</span></a>
      </li>
    </ul>
    <!-- Right CTA Button -->
    <a href="quote.php" class="nav-cta">Request a Quote <span class="cta-icon">&#8594;</span></a>
    <!-- Hamburger Icon -->
    <div class="nav-hamburger" id="hamburger-btn">
      <span></span><span></span><span></span>
    </div>
  </nav>
  <!-- Mobile Menu -->
  <div class="mobile-menu" id="mobile-menu">
    <ul>
      <li><a href="/">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="portfolio.php">Portfolio</a></li>
      <li><a href="services.php">Service</a></li>
      <li><a href="blogs">Blogs</a></li>
      <li><a href="contact.php">Contact Us <span class="cta-icon">&#8594;</span></a></li>
    </ul>
  </div>
</header>

<style>
/* Header Section */
.header-bar {
  position: fixed;
  top: 24px;
  left: 0; right: 0;
  z-index: 9999;
  width: 100%;
  display: flex;
  justify-content: center;
  pointer-events: none;
}
.nav-container {
  width: 90vw;
  max-width: 1300px;
  background: #fff;
  border-radius: 48px;
  box-shadow: 0 6px 32px 0 rgba(32, 50, 90, 0.10);
  display: flex;
  align-items: center;
  padding: 0 32px 0 18px;
  min-height: 74px;
  pointer-events: auto;
  gap: 20px;
}
.nav-logo {
  display: flex;
  align-items: center;
  gap: 0.6em;
  margin-right: 22px;
}
.logo-img {
  max-height: 44px;
  min-width: 44px;
}
.logo-text {
  font-size: 2rem;
  font-weight: 700;
  letter-spacing: -2px;
  margin-top: 1px;
}
.nav-menu {
  display: flex;
  align-items: center;
  gap: 8px;
  list-style: none;
  margin: 0 0 0 16px;
  padding: 0;
  flex: 1 1 auto;
}
.nav-item {
  position: relative;
}
.nav-link {
  display: flex;
  align-items: center;
  font-size: 17px;
  font-weight: 500;
  color: #202834;
  padding: 16px 18px 16px 12px;
  border-radius: 32px;
  text-decoration: none;
  transition: background 0.18s;
}
.nav-link:hover {
  background: #ecf0fa;
  color: #2074ff;
}
.dropdown-icon {
  font-size: 13px;
  margin-left: 5px;
  margin-top: 1px;
}
.search-btn .search-toggle {
  background: none;
  border: none;
  font-size: 20px;
  padding: 10px 10px;
  border-radius: 999px;
  cursor: pointer;
  color: #222;
  transition: background 0.2s;
}
.search-btn .search-toggle:hover {
  background: #ecf0fa;
}
.nav-cta {
  background: #256eff;
  color: #fff;
  font-size: 18px;
  padding: 10px 24px;
  border-radius: 999px;
  font-weight: 600;
  margin-left: 24px;
  display: flex;
  align-items: center;
  text-decoration: none;
  transition: background 0.18s, box-shadow 0.18s;
  box-shadow: 0 2px 20px 0 rgba(32, 58, 255, 0.11);
}
.nav-cta:hover {
  background: #0450d9;
}
.cta-icon {
  font-size: 1.5em;
  margin-left: 10px;
}
.nav-hamburger {
  display: none;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  height: 46px; width: 46px;
  border-radius: 100%;
  margin-left: 18px;
  transition: background 0.2s;
}
.nav-hamburger:hover { background: #f4f7fb;}
.nav-hamburger span {
  display: block;
  background: #222;
  height: 4px; width: 28px;
  border-radius: 2px;
  margin: 3px 0;
  transition: all 0.23s;
}
/* Mobile menu */
.mobile-menu {
  display: none;
  flex-direction: column;
  align-items: center;
  position: fixed;
  top: 100px; left: 0; right: 0;
  background: #fff;
  box-shadow: 0 8px 32px 0 rgba(31,38,135,0.09);
  z-index: 9999;
  border-radius: 0 0 32px 32px;
  padding: 22px 0 26px 0;
  pointer-events: auto;
}
.mobile-menu ul {
  width: 95vw;
  max-width: 360px;
  margin: 0 auto;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.mobile-menu li a, .mobile-menu li {
  display: block;
  padding: 14px 10px;
  color: #2d3652;
  font-size: 18px;
  text-align: left;
  border-radius: 22px;
  text-decoration: none;
  font-weight: 500;
  margin: 0;
  transition: background 0.16s, color 0.12s;
}
.mobile-menu li a:hover {
  background: #ecf0fa;
  color: #0450d9;
}
.mobile-menu .cta-icon {
  margin-left: 8px;
}
@media (max-width: 1100px) {
  .nav-container { width: 98vw; min-width: unset;}
}
@media (max-width: 900px) {
  .nav-container { padding: 0 12px; }
  .logo-text { font-size: 1.35rem; }
  .nav-link { font-size: 16px; padding: 16px 10px;}
  .nav-cta { font-size: 15px; padding: 11px 18px; margin-left: 12px;}
}
@media (max-width: 800px) {
  .nav-menu { gap: 3px; }
  .nav-container { gap:10px;}
}
@media (max-width: 700px) {
  .nav-container { min-height: 58px; border-radius: 36px;}
  .nav-logo .logo-img { max-height: 38px;}
}
@media (max-width: 650px) {
  .nav-menu, .nav-cta { display: none; }
  .nav-hamburger { display: flex; }
  .mobile-menu { border-radius: 0 0 16px 16px; }
  .header-bar {top:10px;}
}
</style>
<script>
const hamburger = document.getElementById("hamburger-btn");
const mobileMenu = document.getElementById("mobile-menu");
let menuOpen = false;
hamburger.addEventListener("click", () => {
  menuOpen = !menuOpen;
  mobileMenu.style.display = menuOpen ? "flex" : "none";
});
window.addEventListener('resize', function() {
  if(window.innerWidth > 650){
    mobileMenu.style.display = 'none';
    menuOpen = false;
  }
});
// Optional: Close menu on link click
mobileMenu.querySelectorAll('a').forEach(link =>
  link.addEventListener('click', () => { 
    mobileMenu.style.display = 'none'; 
    menuOpen = false; 
  })
);
</script>


<section id="hero" class="relative w-full min-h-[40vh] flex items-center justify-center overflow-hidden bg-[#0042AA] text-white">

  <!-- Animated SVG Background -->
  <svg class="absolute inset-0 w-full h-full z-0 pointer-events-none" aria-hidden="true">
    <defs>
      <linearGradient id="heroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop stop-color="#00AAE4" stop-opacity="0.25"/>
        <stop stop-color="#0042AA" stop-opacity="1"/>
      </linearGradient>
    </defs>
    <rect width="100%" height="100%" fill="url(#heroGradient)"/>
    <g>
      <animateTransform attributeName="transform" type="translate" values="0 0;50 0;0 0" dur="4s" repeatCount="indefinite" />
      <path d="M 80 0 L 100 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
      <path d="M 300 0 L 500 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
      <path d="M 700 0 L 900 1000" stroke="#00AAE4" stroke-width="8" opacity="0.07"/>
    </g>
  </svg>

  <!-- Main Content with max-w-7xl -->
  <div class="max-w-7xl mx-auto w-full flex flex-col md:flex-row items-center justify-between z-10 relative">
    <!-- Left Side: Text Content -->
    <div class="flex-1 flex flex-col justify-center pl-8 md:pl-24 pt-24" style="max-width:640px;">
      <h1 class="text-4xl md:text-5xl font-extrabold mb-8 animate-slide-up" style="animation-delay:0.4s">Our Portfolio</h1>
      <p class="text-white max-w-5xl mx-auto">
        Explore the innovative digital solutions we’ve delivered to our clients.
      </p>
    </div>
  </div>
</section>



<section class="pt-28 pb-16 bg-gray-50">
  <div class="max-w-7xl container mx-auto px-4">
    <div class="text-center mb-12">
      <h1 class="text-4xl font-bold mb-4"></h1>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
                  <img src="https://redescreation.in/images/portfolio/brahmos-logistics.jpg" alt="Brahmos Logistics LLC – Global Logistics Solutions Website" class="w-full h-72 object-cover">
                <div class="p-6">
          <h3 class="text-xl font-semibold mb-2 text-blue-900">Brahmos Logistics LLC – Global Logistics Solutions Website</h3>
          <p class="text-gray-600 mb-4">Project Overview
We developed a robust logistics website for Brahmos Logistics LLC, focusing on glo...</p>
          <a href="portfolio-post.php?slug=brahmos-logistics-website" class="text-sm text-blue-800 hover:underline">View Case Study →</a>
        </div>
      </div>
            <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
                  <img src="images/project6.jpg" alt="SmartEdu E-Learning Platform" class="w-full h-72 object-cover">
                <div class="p-6">
          <h3 class="text-xl font-semibold mb-2 text-blue-900">SmartEdu E-Learning Platform</h3>
          <p class="text-gray-600 mb-4">SmartEdu is a robust and scalable e-learning web application built to empower institutions and educa...</p>
          <a href="portfolio-post.php?slug=smartedu-e-learning-platform" class="text-sm text-blue-800 hover:underline">View Case Study →</a>
        </div>
      </div>
          </div>
  </div>
</section>

<!-- Footer -->
<footer class="footer-bg text-white pt-16 pb-8">
  <div class="max-w-7xl container mx-auto px-4">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
      
      <!-- Our Services -->
      <div>
        <h4 class="text-xl font-semibold mb-6">Our Services</h4>
        <ul class="space-y-3">
          <li><a href="#" class="text-gray-300 hover:text-white transition">Web Development</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Digital Marketing</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">UI/UX Design</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">E-commerce Solutions</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Mobile App Development</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Branding & Identity</a></li>
        </ul>
      </div>

      <!-- Quick Links -->
      <!-- Quick Links -->
<div>
  <h4 class="text-xl font-semibold mb-6">Quick Links</h4>
  <ul class="space-y-3">
    <li>
      <a href="index.php" class="text-gray-300 hover:text-white transition">
        Home
      </a>
    </li>
    <li>
      <a href="services.php" class="text-gray-300 hover:text-white transition">
        Services
      </a>
    </li>
    <li>
      <a href="portfolio.php" class="text-gray-300 hover:text-white transition">
        Portfolio
      </a>
    </li>
    <li>
      <a href="about.php" class="text-gray-300 hover:text-white transition">
        About Us
      </a>
    </li>
    <li>
      <a href="contact.php" class="text-gray-300 hover:text-white transition">
        Contact
      </a>
    </li>
    <li>
      <a href="quote.php" class="text-gray-300 hover:text-white transition">
        Request a Quote
      </a>
    </li>
  </ul>
</div>

      <!-- Other Websites -->
      <div>
        <h4 class="text-xl font-semibold mb-6">Other Websites</h4>
        <ul class="space-y-3">
          <li><a href="#" class="text-gray-300 hover:text-white transition">Bhaagya</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Prabh</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Geet</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">E-commerce Solutions</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Paay</a></li>
          <li><a href="#" class="text-gray-300 hover:text-white transition">Destiny Solutions</a></li>
        </ul>
      </div>

      <!-- ✅ Mailchimp Newsletter -->
      <div>
        <h4 class="text-xl font-semibold mb-6">Newsletter</h4>
        <p class="text-gray-300 mb-4">
          Subscribe to our newsletter to receive updates on our latest projects and insights.
        </p>
        <form action="https://redescreation.us12.list-manage.com/subscribe/post?u=9a2df25b21c02476bb963de58&amp;id=2ddf7a4d7d&amp;f_id=003f99e0f0"
              method="post" target="_blank" class="mb-4 flex">
          <input type="email" name="EMAIL" required
                 placeholder="Your email address"
                 class="w-full px-4 py-2 rounded-l text-gray-800 focus:outline-none" />
          <button type="submit"
                  class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-r text-white">
            <i class="ri-send-plane-fill"></i>
          </button>
        </form>
        <p class="text-gray-400 text-sm">
          By subscribing, you agree to our Privacy Policy.
        </p>
      </div>
    </div>

    <!-- Office Addresses -->
    <div class="border-t border-gray-700 pt-8">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
        <div>
          <h4 class="text-xl font-semibold mb-6">Rajasthan</h4>
          <ul class="space-y-3">
            <li class="text-gray-300">Maruti Complex,<br>Abu Road,<br>India – 307026</li>
            <li><a href="tel:+919676659153" class="text-gray-300 hover:text-white transition">+91-9676659153</a></li>
          </ul>
        </div>
        <div>
          <h4 class="text-xl font-semibold mb-6">Gujarat</h4>
          <ul class="space-y-3">
            <li class="text-gray-300">Nikol,<br>Ahmedabad,<br>India – 382350</li>
            <li><a href="tel:+919057071463" class="text-gray-300 hover:text-white transition">+91-9057071463</a></li>
          </ul>
        </div>
        <div>
          <h4 class="text-xl font-semibold mb-6">Andhra Pradesh</h4>
          <ul class="space-y-3">
            <li class="text-gray-300">Kadapa,<br>Krishnapuram,<br>India – 303001</li>
            <li><a href="tel:+919676659153" class="text-gray-300 hover:text-white transition">+91-9676659153</a></li>
          </ul>
        </div>

        <!-- Enquiry & Social Icons -->
        <div class="flex flex-col justify-start items-center gap-4">
          <!-- Buttons -->
          <div class="flex flex-col sm:flex-row gap-4">
            <a href="#" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-md shadow-md text-center w-full sm:w-auto">
              <div class="text-sm text-left">For Enquiries</div>
              <div class="text-lg font-semibold flex items-center justify-center gap-1">
                Contact <i class="ri-arrow-right-s-line"></i>
              </div>
            </a>
            <a href="#" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-md shadow-md text-center w-full sm:w-auto">
              <div class="text-sm text-left">For Career</div>
              <div class="text-lg font-semibold flex items-center justify-center gap-1">
                Apply <i class="ri-arrow-right-s-line"></i>
              </div>
            </a>
          </div>
          <!-- Social -->
          <div class="flex justify-center gap-3 mt-4">
            <a href="https://www.instagram.com/redescreation" class="text-pink-500 text-2xl bg-white rounded-full p-2"><i class="ri-instagram-fill"></i></a>
            <a href="#" class="text-red-600 text-2xl bg-white rounded-full p-2"><i class="ri-pinterest-fill"></i></a>
            <a href="#" class="text-sky-500 text-2xl bg-white rounded-full p-2"><i class="ri-twitter-x-fill"></i></a>
            <a href="#" class="text-red-600 text-2xl bg-white rounded-full p-2"><i class="ri-youtube-fill"></i></a>
            <a href="#" class="text-blue-700 text-2xl bg-white rounded-full p-2"><i class="ri-linkedin-fill"></i></a>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer Bottom -->
    <div class="border-t border-gray-700 pt-8">
      <div class="flex flex-col md:flex-row justify-between items-center">
        <p class="text-gray-400 mb-4 md:mb-0">
          &copy; 2025 Redes Creation. All rights reserved by <a href="https://redescreation.in/" class="text-blue-500">Redes Creation</a>
        </p>
        <div class="flex space-x-6">
          <a href="#" class="text-gray-400 hover:text-white transition">Privacy Policy</a>
          <a href="#" class="text-gray-400 hover:text-white transition">Terms of Service</a>
          <a href="#" class="text-gray-400 hover:text-white transition">Cookie Policy</a>
        </div>
      </div>
    </div>
  </div>


<!--?php include("features/combined-notification.php"); ?-->
<style>
    
.floating-whatsapp {
  position: fixed;
  bottom: 20px;
  left: 20px;
  width: 56px;
  height: 56px;
  background-color: #25D366;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;
  z-index: 9999;
  text-decoration: none;
}

.floating-whatsapp:hover {
  transform: scale(1.1);
}
    </style>
    
    
    
<a href="https://wa.me/919676659153?text=I'm%20interested%20in%20your%20services" class="floating-whatsapp" target="_blank" aria-label="Chat on WhatsApp">
  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 32 32" fill="white">
    <path d="M16.004 2.002c-7.731 0-14.004 6.271-14.004 14.002 0 2.472 0.647 4.875 1.872 7.007l-1.975 7.23 7.396-1.942c1.997 1.09 4.276 1.667 6.711 1.667 7.731 0 14.004-6.271 14.004-14.002s-6.273-14.002-14.004-14.002zM16.004 26.771c-2.076 0-4.076-0.544-5.832-1.574l-0.418-0.246-4.393 1.153 1.173-4.278-0.272-0.438c-1.158-1.859-1.769-4.005-1.769-6.171 0-6.457 5.252-11.709 11.709-11.709s11.709 5.252 11.709 11.709c0 6.456-5.252 11.708-11.709 11.708zM22.142 19.491c-0.344-0.172-2.041-1.007-2.359-1.121-0.319-0.118-0.553-0.172-0.787 0.172s-0.902 1.121-1.107 1.351c-0.204 0.223-0.406 0.252-0.75 0.086-0.344-0.172-1.451-0.533-2.762-1.695-1.022-0.911-1.715-2.039-1.916-2.383-0.201-0.344-0.022-0.53 0.151-0.702 0.155-0.153 0.344-0.398 0.516-0.597 0.17-0.201 0.227-0.344 0.342-0.57 0.118-0.223 0.057-0.43-0.029-0.602-0.086-0.172-0.787-1.9-1.078-2.607-0.283-0.68-0.572-0.588-0.787-0.6-0.202-0.008-0.43-0.009-0.659-0.009s-0.602 0.086-0.916 0.43c-0.319 0.344-1.204 1.174-1.204 2.861s1.233 3.32 1.404 3.547c0.172 0.223 2.435 3.711 5.902 5.204 0.826 0.357 1.47 0.57 1.971 0.729 0.827 0.263 1.578 0.226 2.172 0.137 0.662-0.099 2.041-0.834 2.328-1.641 0.287-0.807 0.287-1.499 0.201-1.641-0.086-0.143-0.316-0.229-0.66-0.398z"/>
  </svg>
</a>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Floating Call Button</title>
  <style>
    .floating-call {
      position: fixed;
      bottom: 90px;
      right: 20px;
      width: 56px;
      height: 56px;
      background-color: #007BFF;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
      z-index: 9999;
      text-decoration: none;
    }
    .floating-call:hover {
      transform: scale(1.1);
    }
    .floating-call svg {
      width: 28px;
      height: 28px;
      fill: white;
    }
  </style>
</head>
<body>

<a href="tel:+919676659153" class="floating-call" aria-label="Call Us">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M391.2 351.3c-36.1 0-71.2-5.8-104.6-17.3-19.4-6.7-41.2-16.6-66.1-30.4-36.3-20.2-62.3-42.4-78.5-66.4-10.5-15.3-18.1-32.3-22.5-51-3.4-14.1 2.7-28.9 15.3-36.8l51.6-32c10.4-6.5 23.8-5.1 32.5 3.4l35.6 35.6c10.4 10.4 11.9 27.3 3.3 39.4l-20.6 30.2c3.5 4.7 9.6 11.5 21.4 20.7 17.4 13.7 32.7 22.2 46.2 25.5l22.3-22.3c10.4-10.4 27.3-11.9 39.4-3.3l35.6 35.6c8.5 8.5 9.9 22 3.4 32.5l-32 51.6c-5.5 8.9-15.1 14.1-25.4 14.1z"/></svg>
</a>

</body>
</html><!--?php include("features/scroll-progress.php"); ?-->
<!--?php include("features/cookie-consent.php"); ?--->
<!----?php include("features/smg-style-notification.php"); ?---->


  <!-- Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-4VBPBHNW3C"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-4VBPBHNW3C');
  </script>
</footer>